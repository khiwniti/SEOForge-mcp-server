<?php
/**
 * SEO Forge - Universal SEO WordPress Plugin
 *
 * @package      SEO_FORGE
 * @copyright    Copyright (C) 2024, SEO Forge Team
 * @link         https://github.com/khiwniti/SEOForge-mcp-server
 * @since        1.0.0
 *
 * @wordpress-plugin
 * Plugin Name:       SEO Forge
 * Version:           1.0.0
 * Plugin URI:        https://github.com/khiwniti/SEOForge-mcp-server
 * Description:       Universal SEO WordPress plugin with AI-powered content generation, SEO analysis, and comprehensive optimization tools. No license required.
 * Author:            SEO Forge Team
 * Author URI:        https://github.com/khiwniti/SEOForge-mcp-server
 * License:           MIT
 * License URI:       https://opensource.org/licenses/MIT
 * Text Domain:       seo-forge
 * Domain Path:       /languages
 * Requires at least: 5.0
 * Tested up to:      6.4
 * Requires PHP:      7.4
 * Network:           false
 */

defined( 'ABSPATH' ) || exit;

/**
 * SEO Forge main class.
 *
 * @class The class that holds the entire plugin.
 */
final class SEOForge {

	/**
	 * Plugin version
	 *
	 * @var string
	 */
	public $version = '1.0.0';

	/**
	 * Holds various class instances
	 *
	 * @var array
	 */
	private $container = [];

	/**
	 * The single instance of the class
	 *
	 * @var SEOForge
	 */
	protected static $instance = null;

	/**
	 * Main SEOForge instance.
	 *
	 * Ensure only one instance is loaded or can be loaded.
	 *
	 * @see seo_forge()
	 * @return SEOForge
	 */
	public static function get() {
		if ( is_null( self::$instance ) && ! ( self::$instance instanceof SEOForge ) ) {
			self::$instance = new SEOForge();
		}
		return self::$instance;
	}

	/**
	 * Class constructor.
	 */
	private function __construct() {
		$this->define_constants();
		$this->includes();
		$this->init_hooks();

		add_action( 'after_setup_theme', [ $this, 'localization_setup' ], 1 );
		add_action( 'init', [ $this, 'init' ], 0 );
	}

	/**
	 * Hook into actions and filters.
	 */
	private function init_hooks() {
		register_activation_hook( __FILE__, [ $this, 'activate' ] );
		register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );
	}

	/**
	 * Define the plugin constants.
	 */
	private function define_constants() {
		define( 'SEO_FORGE_VERSION', $this->version );
		define( 'SEO_FORGE_FILE', __FILE__ );
		define( 'SEO_FORGE_PATH', dirname( SEO_FORGE_FILE ) . '/' );
		define( 'SEO_FORGE_URL', plugins_url( '', SEO_FORGE_FILE ) . '/' );
		define( 'SEO_FORGE_ASSETS_URL', SEO_FORGE_URL . 'assets/' );
		define( 'SEO_FORGE_ADMIN_URL', SEO_FORGE_ASSETS_URL . 'admin/' );
	}

	/**
	 * Include the required files.
	 */
	private function includes() {
		// Core includes
		include_once SEO_FORGE_PATH . 'includes/class-installer.php';
		include_once SEO_FORGE_PATH . 'includes/class-common.php';
		include_once SEO_FORGE_PATH . 'includes/class-helper.php';
		include_once SEO_FORGE_PATH . 'includes/class-mcp-client.php';
		
		// Admin includes
		if ( is_admin() ) {
			include_once SEO_FORGE_PATH . 'includes/admin/class-admin.php';
			include_once SEO_FORGE_PATH . 'includes/admin/class-admin-helper.php';
			include_once SEO_FORGE_PATH . 'includes/admin/class-meta-box.php';
			include_once SEO_FORGE_PATH . 'includes/admin/class-settings.php';
		}

		// API includes
		include_once SEO_FORGE_PATH . 'includes/api/class-rest-api.php';
		
		// Module includes
		include_once SEO_FORGE_PATH . 'includes/modules/class-content-generator.php';
		include_once SEO_FORGE_PATH . 'includes/modules/class-seo-analyzer.php';
		include_once SEO_FORGE_PATH . 'includes/modules/class-keyword-research.php';
	}

	/**
	 * Initialize the plugin.
	 */
	public function init() {
		// Initialize core components
		$this->container['installer'] = new SEOForge\Installer();
		$this->container['common'] = new SEOForge\Common();
		$this->container['helper'] = new SEOForge\Helper();
		$this->container['mcp_client'] = new SEOForge\MCP_Client();

		// Initialize admin components
		if ( is_admin() ) {
			$this->container['admin'] = new SEOForge\Admin\Admin();
		}

		// Initialize API
		$this->container['rest_api'] = new SEOForge\API\Rest_API();

		// Initialize modules
		$this->container['content_generator'] = new SEOForge\Modules\Content_Generator();
		$this->container['seo_analyzer'] = new SEOForge\Modules\SEO_Analyzer();
		$this->container['keyword_research'] = new SEOForge\Modules\Keyword_Research();

		// Loaded action
		do_action( 'seo_forge/loaded' );
	}

	/**
	 * Initialize plugin for localization.
	 */
	public function localization_setup() {
		$locale = is_admin() && function_exists( 'get_user_locale' ) ? get_user_locale() : get_locale();
		$locale = apply_filters( 'plugin_locale', $locale, 'seo-forge' );

		unload_textdomain( 'seo-forge' );
		load_textdomain( 'seo-forge', WP_LANG_DIR . '/plugins/seo-forge-' . $locale . '.mo' );
		load_plugin_textdomain( 'seo-forge', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
	}

	/**
	 * Plugin activation.
	 */
	public function activate() {
		// Create database tables if needed
		if ( class_exists( 'SEOForge\Installer' ) ) {
			SEOForge\Installer::activate();
		}

		// Set default options
		$this->set_default_options();

		// Flush rewrite rules
		flush_rewrite_rules();
	}

	/**
	 * Plugin deactivation.
	 */
	public function deactivate() {
		// Cleanup if needed
		flush_rewrite_rules();
	}

	/**
	 * Set default plugin options.
	 */
	private function set_default_options() {
		$defaults = [
			'seo_forge_api_url' => 'https://seoforge-mcp-platform.vercel.app',
			'seo_forge_api_key' => '',
			'seo_forge_default_language' => 'en',
			'seo_forge_auto_generate' => false,
			'seo_forge_enable_analytics' => true,
			'seo_forge_enable_content_ai' => true,
			'seo_forge_enable_keyword_research' => true,
		];

		foreach ( $defaults as $option => $value ) {
			if ( false === get_option( $option ) ) {
				add_option( $option, $value );
			}
		}
	}

	/**
	 * Get container instance.
	 *
	 * @param string $key Container key.
	 * @return mixed
	 */
	public function get_container( $key ) {
		return isset( $this->container[ $key ] ) ? $this->container[ $key ] : null;
	}
}

/**
 * Returns the main instance of SEOForge to prevent the need to use globals.
 *
 * @return SEOForge
 */
function seo_forge() {
	return SEOForge::get();
}

// Start the plugin
seo_forge();