<?php
/**
 * SEO Forge Common Class
 *
 * @package SEO_FORGE
 */

namespace SEOForge;

defined( 'ABSPATH' ) || exit;

/**
 * Common class.
 */
class Common {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'wp_enqueue_scripts', [ $this, 'enqueue_frontend_scripts' ] );
		add_action( 'wp_head', [ $this, 'add_meta_tags' ] );
		add_filter( 'document_title_parts', [ $this, 'filter_title_parts' ] );
		add_filter( 'wp_title', [ $this, 'filter_wp_title' ], 10, 2 );
	}

	/**
	 * Enqueue frontend scripts and styles.
	 */
	public function enqueue_frontend_scripts() {
		// Frontend CSS
		wp_enqueue_style(
			'seo-forge-frontend',
			SEO_FORGE_ASSETS_URL . 'frontend/css/frontend.css',
			[],
			SEO_FORGE_VERSION
		);

		// Frontend JS
		wp_enqueue_script(
			'seo-forge-frontend',
			SEO_FORGE_ASSETS_URL . 'frontend/js/frontend.js',
			[ 'jquery' ],
			SEO_FORGE_VERSION,
			true
		);

		// Localize script
		wp_localize_script( 'seo-forge-frontend', 'seoForge', [
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'seo_forge_nonce' ),
			'apiUrl' => Helper::get_api_url(),
			'strings' => [
				'loading' => __( 'Loading...', 'seo-forge' ),
				'error' => __( 'An error occurred. Please try again.', 'seo-forge' ),
			],
		] );
	}

	/**
	 * Add meta tags to head.
	 */
	public function add_meta_tags() {
		global $post;

		if ( is_singular() && $post ) {
			$this->add_post_meta_tags( $post );
		} elseif ( is_category() || is_tag() || is_tax() ) {
			$this->add_term_meta_tags();
		} elseif ( is_home() || is_front_page() ) {
			$this->add_homepage_meta_tags();
		}

		// Add generator meta tag
		echo '<meta name="generator" content="SEO Forge ' . SEO_FORGE_VERSION . '" />' . "\n";
	}

	/**
	 * Add post meta tags.
	 *
	 * @param WP_Post $post Post object.
	 */
	private function add_post_meta_tags( $post ) {
		// Meta description
		$meta_description = get_post_meta( $post->ID, '_seo_forge_meta_description', true );
		if ( ! $meta_description ) {
			$meta_description = wp_trim_words( strip_tags( $post->post_content ), 25 );
		}
		if ( $meta_description ) {
			echo '<meta name="description" content="' . esc_attr( $meta_description ) . '" />' . "\n";
		}

		// Meta keywords
		$meta_keywords = get_post_meta( $post->ID, '_seo_forge_meta_keywords', true );
		if ( $meta_keywords ) {
			echo '<meta name="keywords" content="' . esc_attr( $meta_keywords ) . '" />' . "\n";
		}

		// Open Graph tags
		$this->add_open_graph_tags( $post );

		// Twitter Card tags
		$this->add_twitter_card_tags( $post );

		// Schema.org markup
		$this->add_schema_markup( $post );
	}

	/**
	 * Add term meta tags.
	 */
	private function add_term_meta_tags() {
		$term = get_queried_object();
		if ( ! $term ) {
			return;
		}

		// Meta description
		$meta_description = get_term_meta( $term->term_id, '_seo_forge_meta_description', true );
		if ( ! $meta_description && $term->description ) {
			$meta_description = wp_trim_words( strip_tags( $term->description ), 25 );
		}
		if ( $meta_description ) {
			echo '<meta name="description" content="' . esc_attr( $meta_description ) . '" />' . "\n";
		}

		// Meta keywords
		$meta_keywords = get_term_meta( $term->term_id, '_seo_forge_meta_keywords', true );
		if ( $meta_keywords ) {
			echo '<meta name="keywords" content="' . esc_attr( $meta_keywords ) . '" />' . "\n";
		}
	}

	/**
	 * Add homepage meta tags.
	 */
	private function add_homepage_meta_tags() {
		$meta_description = get_option( 'seo_forge_homepage_description' );
		if ( ! $meta_description ) {
			$meta_description = get_bloginfo( 'description' );
		}
		if ( $meta_description ) {
			echo '<meta name="description" content="' . esc_attr( $meta_description ) . '" />' . "\n";
		}

		$meta_keywords = get_option( 'seo_forge_homepage_keywords' );
		if ( $meta_keywords ) {
			echo '<meta name="keywords" content="' . esc_attr( $meta_keywords ) . '" />' . "\n";
		}
	}

	/**
	 * Add Open Graph tags.
	 *
	 * @param WP_Post $post Post object.
	 */
	private function add_open_graph_tags( $post ) {
		echo '<meta property="og:type" content="article" />' . "\n";
		echo '<meta property="og:title" content="' . esc_attr( get_the_title( $post ) ) . '" />' . "\n";
		echo '<meta property="og:url" content="' . esc_attr( get_permalink( $post ) ) . '" />' . "\n";
		echo '<meta property="og:site_name" content="' . esc_attr( get_bloginfo( 'name' ) ) . '" />' . "\n";

		$og_description = get_post_meta( $post->ID, '_seo_forge_og_description', true );
		if ( ! $og_description ) {
			$og_description = get_post_meta( $post->ID, '_seo_forge_meta_description', true );
		}
		if ( ! $og_description ) {
			$og_description = wp_trim_words( strip_tags( $post->post_content ), 25 );
		}
		if ( $og_description ) {
			echo '<meta property="og:description" content="' . esc_attr( $og_description ) . '" />' . "\n";
		}

		// Featured image
		if ( has_post_thumbnail( $post ) ) {
			$image_url = get_the_post_thumbnail_url( $post, 'large' );
			echo '<meta property="og:image" content="' . esc_attr( $image_url ) . '" />' . "\n";
		}
	}

	/**
	 * Add Twitter Card tags.
	 *
	 * @param WP_Post $post Post object.
	 */
	private function add_twitter_card_tags( $post ) {
		echo '<meta name="twitter:card" content="summary_large_image" />' . "\n";
		echo '<meta name="twitter:title" content="' . esc_attr( get_the_title( $post ) ) . '" />' . "\n";

		$twitter_description = get_post_meta( $post->ID, '_seo_forge_twitter_description', true );
		if ( ! $twitter_description ) {
			$twitter_description = get_post_meta( $post->ID, '_seo_forge_meta_description', true );
		}
		if ( ! $twitter_description ) {
			$twitter_description = wp_trim_words( strip_tags( $post->post_content ), 25 );
		}
		if ( $twitter_description ) {
			echo '<meta name="twitter:description" content="' . esc_attr( $twitter_description ) . '" />' . "\n";
		}

		// Featured image
		if ( has_post_thumbnail( $post ) ) {
			$image_url = get_the_post_thumbnail_url( $post, 'large' );
			echo '<meta name="twitter:image" content="' . esc_attr( $image_url ) . '" />' . "\n";
		}

		// Twitter handle
		$twitter_handle = get_option( 'seo_forge_twitter_handle' );
		if ( $twitter_handle ) {
			echo '<meta name="twitter:site" content="@' . esc_attr( $twitter_handle ) . '" />' . "\n";
		}
	}

	/**
	 * Add Schema.org markup.
	 *
	 * @param WP_Post $post Post object.
	 */
	private function add_schema_markup( $post ) {
		$schema = [
			'@context' => 'https://schema.org',
			'@type' => 'Article',
			'headline' => get_the_title( $post ),
			'url' => get_permalink( $post ),
			'datePublished' => get_the_date( 'c', $post ),
			'dateModified' => get_the_modified_date( 'c', $post ),
			'author' => [
				'@type' => 'Person',
				'name' => get_the_author_meta( 'display_name', $post->post_author ),
			],
			'publisher' => [
				'@type' => 'Organization',
				'name' => get_bloginfo( 'name' ),
				'url' => home_url(),
			],
		];

		// Add description
		$description = get_post_meta( $post->ID, '_seo_forge_meta_description', true );
		if ( ! $description ) {
			$description = wp_trim_words( strip_tags( $post->post_content ), 25 );
		}
		if ( $description ) {
			$schema['description'] = $description;
		}

		// Add image
		if ( has_post_thumbnail( $post ) ) {
			$schema['image'] = get_the_post_thumbnail_url( $post, 'large' );
		}

		echo '<script type="application/ld+json">' . wp_json_encode( $schema ) . '</script>' . "\n";
	}

	/**
	 * Filter title parts.
	 *
	 * @param array $title_parts Title parts.
	 * @return array
	 */
	public function filter_title_parts( $title_parts ) {
		global $post;

		if ( is_singular() && $post ) {
			$custom_title = get_post_meta( $post->ID, '_seo_forge_title', true );
			if ( $custom_title ) {
				$title_parts['title'] = $custom_title;
			}
		} elseif ( is_category() || is_tag() || is_tax() ) {
			$term = get_queried_object();
			if ( $term ) {
				$custom_title = get_term_meta( $term->term_id, '_seo_forge_title', true );
				if ( $custom_title ) {
					$title_parts['title'] = $custom_title;
				}
			}
		} elseif ( is_home() || is_front_page() ) {
			$custom_title = get_option( 'seo_forge_homepage_title' );
			if ( $custom_title ) {
				$title_parts['title'] = $custom_title;
			}
		}

		return $title_parts;
	}

	/**
	 * Filter wp_title.
	 *
	 * @param string $title Title.
	 * @param string $sep Separator.
	 * @return string
	 */
	public function filter_wp_title( $title, $sep ) {
		global $post;

		if ( is_singular() && $post ) {
			$custom_title = get_post_meta( $post->ID, '_seo_forge_title', true );
			if ( $custom_title ) {
				return $custom_title . ' ' . $sep . ' ' . get_bloginfo( 'name' );
			}
		}

		return $title;
	}
}