<?php
/**
 * SEO Forge Helper Class
 *
 * @package SEO_FORGE
 */

namespace SEOForge;

defined( 'ABSPATH' ) || exit;

/**
 * Helper class.
 */
class Helper {

	/**
	 * Check if module is active.
	 *
	 * @param string $module Module name.
	 * @return bool
	 */
	public static function is_module_active( $module ) {
		$active_modules = get_option( 'seo_forge_active_modules', [] );
		return in_array( $module, $active_modules, true );
	}

	/**
	 * Get API URL.
	 *
	 * @return string
	 */
	public static function get_api_url() {
		return get_option( 'seo_forge_api_url', 'https://seoforge-mcp-platform.vercel.app' );
	}

	/**
	 * Get API Key.
	 *
	 * @return string
	 */
	public static function get_api_key() {
		return get_option( 'seo_forge_api_key', '' );
	}

	/**
	 * Check if WooCommerce is active.
	 *
	 * @return bool
	 */
	public static function is_woocommerce_active() {
		return class_exists( 'WooCommerce' );
	}

	/**
	 * Check if Elementor is active.
	 *
	 * @return bool
	 */
	public static function is_elementor_active() {
		return defined( 'ELEMENTOR_VERSION' );
	}

	/**
	 * Check if Gutenberg is active.
	 *
	 * @return bool
	 */
	public static function is_gutenberg_active() {
		return function_exists( 'register_block_type' );
	}

	/**
	 * Get current user capabilities.
	 *
	 * @return array
	 */
	public static function get_user_capabilities() {
		$user = wp_get_current_user();
		return $user->allcaps ?? [];
	}

	/**
	 * Check if user can manage SEO.
	 *
	 * @return bool
	 */
	public static function can_manage_seo() {
		return current_user_can( 'manage_options' ) || current_user_can( 'edit_posts' );
	}

	/**
	 * Get post types for SEO.
	 *
	 * @return array
	 */
	public static function get_accessible_post_types() {
		$post_types = get_post_types( [ 'public' => true ], 'objects' );
		$accessible = [];

		foreach ( $post_types as $post_type ) {
			if ( current_user_can( $post_type->cap->edit_posts ) ) {
				$accessible[] = $post_type->name;
			}
		}

		return $accessible;
	}

	/**
	 * Get taxonomies for SEO.
	 *
	 * @return array
	 */
	public static function get_accessible_taxonomies() {
		$taxonomies = get_taxonomies( [ 'public' => true ], 'objects' );
		$accessible = [];

		foreach ( $taxonomies as $taxonomy ) {
			if ( current_user_can( $taxonomy->cap->manage_terms ) ) {
				$accessible[] = $taxonomy->name;
			}
		}

		return $accessible;
	}

	/**
	 * Sanitize text field.
	 *
	 * @param string $text Text to sanitize.
	 * @return string
	 */
	public static function sanitize_text( $text ) {
		return sanitize_text_field( wp_unslash( $text ) );
	}

	/**
	 * Sanitize textarea field.
	 *
	 * @param string $text Text to sanitize.
	 * @return string
	 */
	public static function sanitize_textarea( $text ) {
		return sanitize_textarea_field( wp_unslash( $text ) );
	}

	/**
	 * Get default language.
	 *
	 * @return string
	 */
	public static function get_default_language() {
		return get_option( 'seo_forge_default_language', 'en' );
	}

	/**
	 * Get supported languages.
	 *
	 * @return array
	 */
	public static function get_supported_languages() {
		return [
			'en' => __( 'English', 'seo-forge' ),
			'th' => __( 'Thai', 'seo-forge' ),
			'es' => __( 'Spanish', 'seo-forge' ),
			'fr' => __( 'French', 'seo-forge' ),
			'de' => __( 'German', 'seo-forge' ),
			'it' => __( 'Italian', 'seo-forge' ),
			'pt' => __( 'Portuguese', 'seo-forge' ),
			'ru' => __( 'Russian', 'seo-forge' ),
			'ja' => __( 'Japanese', 'seo-forge' ),
			'ko' => __( 'Korean', 'seo-forge' ),
			'zh' => __( 'Chinese', 'seo-forge' ),
		];
	}

	/**
	 * Get industries list.
	 *
	 * @return array
	 */
	public static function get_industries() {
		return [
			'technology' => __( 'Technology', 'seo-forge' ),
			'healthcare' => __( 'Healthcare', 'seo-forge' ),
			'finance' => __( 'Finance', 'seo-forge' ),
			'education' => __( 'Education', 'seo-forge' ),
			'retail' => __( 'Retail', 'seo-forge' ),
			'automotive' => __( 'Automotive', 'seo-forge' ),
			'real-estate' => __( 'Real Estate', 'seo-forge' ),
			'travel' => __( 'Travel', 'seo-forge' ),
			'food' => __( 'Food & Beverage', 'seo-forge' ),
			'fashion' => __( 'Fashion', 'seo-forge' ),
			'sports' => __( 'Sports', 'seo-forge' ),
			'entertainment' => __( 'Entertainment', 'seo-forge' ),
			'other' => __( 'Other', 'seo-forge' ),
		];
	}

	/**
	 * Format file size.
	 *
	 * @param int $size Size in bytes.
	 * @return string
	 */
	public static function format_file_size( $size ) {
		$units = [ 'B', 'KB', 'MB', 'GB', 'TB' ];
		$power = $size > 0 ? floor( log( $size, 1024 ) ) : 0;
		return number_format( $size / pow( 1024, $power ), 2, '.', ',' ) . ' ' . $units[ $power ];
	}

	/**
	 * Get plugin info.
	 *
	 * @return array
	 */
	public static function get_plugin_info() {
		return [
			'name' => 'SEO Forge',
			'version' => SEO_FORGE_VERSION,
			'url' => 'https://github.com/khiwniti/SEOForge-mcp-server',
			'author' => 'SEO Forge Team',
			'license' => 'MIT',
		];
	}

	/**
	 * Check if debug mode is enabled.
	 *
	 * @return bool
	 */
	public static function is_debug_mode() {
		return defined( 'WP_DEBUG' ) && WP_DEBUG;
	}

	/**
	 * Log debug message.
	 *
	 * @param string $message Message to log.
	 * @param string $level Log level.
	 */
	public static function log( $message, $level = 'info' ) {
		if ( self::is_debug_mode() ) {
			error_log( sprintf( '[SEO Forge %s] %s', strtoupper( $level ), $message ) );
		}
	}
}