<?php
/**
 * SEO Forge Admin Class
 *
 * @package SEO_FORGE
 */

namespace SEOForge\Admin;

use SEOForge\Helper;

defined( 'ABSPATH' ) || exit;

/**
 * Admin class.
 */
class Admin {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'admin_menu', [ $this, 'add_admin_menu' ] );
		add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_admin_scripts' ] );
		add_action( 'admin_init', [ $this, 'admin_init' ] );
		add_action( 'admin_notices', [ $this, 'admin_notices' ] );
		add_action( 'add_meta_boxes', [ $this, 'add_meta_boxes' ] );
		add_action( 'save_post', [ $this, 'save_post_meta' ] );
		add_filter( 'plugin_action_links_' . plugin_basename( SEO_FORGE_FILE ), [ $this, 'plugin_action_links' ] );
	}

	/**
	 * Add admin menu.
	 */
	public function add_admin_menu() {
		// Main menu
		add_menu_page(
			__( 'SEO Forge', 'seo-forge' ),
			__( 'SEO Forge', 'seo-forge' ),
			'manage_options',
			'seo-forge',
			[ $this, 'dashboard_page' ],
			$this->get_menu_icon(),
			30
		);

		// Dashboard submenu
		add_submenu_page(
			'seo-forge',
			__( 'Dashboard', 'seo-forge' ),
			__( 'Dashboard', 'seo-forge' ),
			'manage_options',
			'seo-forge',
			[ $this, 'dashboard_page' ]
		);

		// Content Generator
		add_submenu_page(
			'seo-forge',
			__( 'Content Generator', 'seo-forge' ),
			__( 'Content Generator', 'seo-forge' ),
			'edit_posts',
			'seo-forge-content-generator',
			[ $this, 'content_generator_page' ]
		);

		// SEO Analyzer
		add_submenu_page(
			'seo-forge',
			__( 'SEO Analyzer', 'seo-forge' ),
			__( 'SEO Analyzer', 'seo-forge' ),
			'edit_posts',
			'seo-forge-seo-analyzer',
			[ $this, 'seo_analyzer_page' ]
		);

		// Keyword Research
		add_submenu_page(
			'seo-forge',
			__( 'Keyword Research', 'seo-forge' ),
			__( 'Keyword Research', 'seo-forge' ),
			'edit_posts',
			'seo-forge-keyword-research',
			[ $this, 'keyword_research_page' ]
		);

		// Analytics
		add_submenu_page(
			'seo-forge',
			__( 'Analytics', 'seo-forge' ),
			__( 'Analytics', 'seo-forge' ),
			'manage_options',
			'seo-forge-analytics',
			[ $this, 'analytics_page' ]
		);

		// Settings
		add_submenu_page(
			'seo-forge',
			__( 'Settings', 'seo-forge' ),
			__( 'Settings', 'seo-forge' ),
			'manage_options',
			'seo-forge-settings',
			[ $this, 'settings_page' ]
		);
	}

	/**
	 * Get menu icon.
	 *
	 * @return string
	 */
	private function get_menu_icon() {
		return 'data:image/svg+xml;base64,' . base64_encode(
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="currentColor">
				<path d="M12 2L2 7v10c0 5.55 3.84 9.74 9 11 5.16-1.26 9-5.45 9-11V7l-10-5z"/>
				<path d="M9 12l2 2 4-4" stroke="white" stroke-width="2" fill="none"/>
			</svg>'
		);
	}

	/**
	 * Enqueue admin scripts and styles.
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_admin_scripts( $hook ) {
		// Only load on SEO Forge pages
		if ( strpos( $hook, 'seo-forge' ) === false && ! in_array( $hook, [ 'post.php', 'post-new.php', 'edit.php' ], true ) ) {
			return;
		}

		// Admin CSS
		wp_enqueue_style(
			'seo-forge-admin',
			SEO_FORGE_ADMIN_URL . 'css/admin.css',
			[],
			SEO_FORGE_VERSION
		);

		// Admin JS
		wp_enqueue_script(
			'seo-forge-admin',
			SEO_FORGE_ADMIN_URL . 'js/admin.js',
			[ 'jquery', 'wp-util' ],
			SEO_FORGE_VERSION,
			true
		);

		// Chart.js for analytics
		if ( strpos( $hook, 'seo-forge-analytics' ) !== false ) {
			wp_enqueue_script(
				'chart-js',
				'https://cdn.jsdelivr.net/npm/chart.js',
				[],
				'3.9.1',
				true
			);
		}

		// Localize script
		wp_localize_script( 'seo-forge-admin', 'seoForgeAdmin', [
			'ajaxUrl' => admin_url( 'admin-ajax.php' ),
			'nonce' => wp_create_nonce( 'seo_forge_nonce' ),
			'apiUrl' => Helper::get_api_url(),
			'strings' => [
				'generating' => __( 'Generating content...', 'seo-forge' ),
				'analyzing' => __( 'Analyzing SEO...', 'seo-forge' ),
				'researching' => __( 'Researching keywords...', 'seo-forge' ),
				'optimizing' => __( 'Optimizing content...', 'seo-forge' ),
				'loading' => __( 'Loading...', 'seo-forge' ),
				'error' => __( 'An error occurred. Please try again.', 'seo-forge' ),
				'success' => __( 'Operation completed successfully.', 'seo-forge' ),
				'confirm' => __( 'Are you sure?', 'seo-forge' ),
			],
		] );
	}

	/**
	 * Admin init.
	 */
	public function admin_init() {
		// Register settings
		register_setting( 'seo_forge_settings', 'seo_forge_api_url' );
		register_setting( 'seo_forge_settings', 'seo_forge_api_key' );
		register_setting( 'seo_forge_settings', 'seo_forge_default_language' );
		register_setting( 'seo_forge_settings', 'seo_forge_auto_generate' );
		register_setting( 'seo_forge_settings', 'seo_forge_enable_analytics' );
		register_setting( 'seo_forge_settings', 'seo_forge_enable_content_ai' );
		register_setting( 'seo_forge_settings', 'seo_forge_enable_keyword_research' );
	}

	/**
	 * Admin notices.
	 */
	public function admin_notices() {
		// Check if API is configured
		if ( empty( Helper::get_api_url() ) && $this->is_seo_forge_page() ) {
			echo '<div class="notice notice-warning is-dismissible">';
			echo '<p>' . sprintf(
				__( 'SEO Forge API URL is not configured. Please <a href="%s">configure it</a> to use all features.', 'seo-forge' ),
				admin_url( 'admin.php?page=seo-forge-settings' )
			) . '</p>';
			echo '</div>';
		}
	}

	/**
	 * Check if current page is SEO Forge page.
	 *
	 * @return bool
	 */
	private function is_seo_forge_page() {
		$screen = get_current_screen();
		return $screen && strpos( $screen->id, 'seo-forge' ) !== false;
	}

	/**
	 * Add meta boxes.
	 */
	public function add_meta_boxes() {
		$post_types = Helper::get_accessible_post_types();

		foreach ( $post_types as $post_type ) {
			// SEO Meta Box
			add_meta_box(
				'seo-forge-seo-meta',
				__( 'SEO Forge - SEO Settings', 'seo-forge' ),
				[ $this, 'seo_meta_box' ],
				$post_type,
				'normal',
				'high'
			);

			// Content Generator Meta Box
			add_meta_box(
				'seo-forge-content-generator',
				__( 'SEO Forge - Content Generator', 'seo-forge' ),
				[ $this, 'content_generator_meta_box' ],
				$post_type,
				'side',
				'high'
			);

			// SEO Analysis Meta Box
			add_meta_box(
				'seo-forge-seo-analysis',
				__( 'SEO Forge - SEO Analysis', 'seo-forge' ),
				[ $this, 'seo_analysis_meta_box' ],
				$post_type,
				'side',
				'high'
			);
		}
	}

	/**
	 * SEO meta box.
	 *
	 * @param WP_Post $post Post object.
	 */
	public function seo_meta_box( $post ) {
		wp_nonce_field( 'seo_forge_meta_box', 'seo_forge_meta_box_nonce' );

		$title = get_post_meta( $post->ID, '_seo_forge_title', true );
		$description = get_post_meta( $post->ID, '_seo_forge_meta_description', true );
		$keywords = get_post_meta( $post->ID, '_seo_forge_meta_keywords', true );
		$focus_keyword = get_post_meta( $post->ID, '_seo_forge_focus_keyword', true );

		include SEO_FORGE_PATH . 'templates/admin/meta-box-seo.php';
	}

	/**
	 * Content generator meta box.
	 *
	 * @param WP_Post $post Post object.
	 */
	public function content_generator_meta_box( $post ) {
		$keywords = get_post_meta( $post->ID, '_seo_forge_keywords', true );
		$industry = get_post_meta( $post->ID, '_seo_forge_industry', true );

		include SEO_FORGE_PATH . 'templates/admin/meta-box-content-generator.php';
	}

	/**
	 * SEO analysis meta box.
	 *
	 * @param WP_Post $post Post object.
	 */
	public function seo_analysis_meta_box( $post ) {
		$last_analysis = get_post_meta( $post->ID, '_seo_forge_last_analysis', true );
		$seo_score = get_post_meta( $post->ID, '_seo_forge_seo_score', true );

		include SEO_FORGE_PATH . 'templates/admin/meta-box-seo-analysis.php';
	}

	/**
	 * Save post meta.
	 *
	 * @param int $post_id Post ID.
	 */
	public function save_post_meta( $post_id ) {
		if ( ! isset( $_POST['seo_forge_meta_box_nonce'] ) || 
			 ! wp_verify_nonce( $_POST['seo_forge_meta_box_nonce'], 'seo_forge_meta_box' ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		if ( ! current_user_can( 'edit_post', $post_id ) ) {
			return;
		}

		// Save SEO meta fields
		$fields = [
			'_seo_forge_title',
			'_seo_forge_meta_description',
			'_seo_forge_meta_keywords',
			'_seo_forge_focus_keyword',
			'_seo_forge_keywords',
			'_seo_forge_industry',
		];

		foreach ( $fields as $field ) {
			$key = str_replace( '_seo_forge_', '', $field );
			if ( isset( $_POST[ $key ] ) ) {
				update_post_meta( $post_id, $field, Helper::sanitize_text( $_POST[ $key ] ) );
			}
		}
	}

	/**
	 * Plugin action links.
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function plugin_action_links( $links ) {
		$settings_link = '<a href="' . admin_url( 'admin.php?page=seo-forge-settings' ) . '">' . __( 'Settings', 'seo-forge' ) . '</a>';
		array_unshift( $links, $settings_link );
		return $links;
	}

	/**
	 * Dashboard page.
	 */
	public function dashboard_page() {
		include SEO_FORGE_PATH . 'templates/admin/dashboard.php';
	}

	/**
	 * Content generator page.
	 */
	public function content_generator_page() {
		include SEO_FORGE_PATH . 'templates/admin/content-generator.php';
	}

	/**
	 * SEO analyzer page.
	 */
	public function seo_analyzer_page() {
		include SEO_FORGE_PATH . 'templates/admin/seo-analyzer.php';
	}

	/**
	 * Keyword research page.
	 */
	public function keyword_research_page() {
		include SEO_FORGE_PATH . 'templates/admin/keyword-research.php';
	}

	/**
	 * Analytics page.
	 */
	public function analytics_page() {
		include SEO_FORGE_PATH . 'templates/admin/analytics.php';
	}

	/**
	 * Settings page.
	 */
	public function settings_page() {
		include SEO_FORGE_PATH . 'templates/admin/settings.php';
	}
}