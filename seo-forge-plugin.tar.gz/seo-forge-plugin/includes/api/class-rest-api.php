<?php
/**
 * SEO Forge REST API Class
 *
 * @package SEO_FORGE
 */

namespace SEOForge\API;

use SEOForge\Helper;

defined( 'ABSPATH' ) || exit;

/**
 * REST API class.
 */
class Rest_API {

	/**
	 * Constructor.
	 */
	public function __construct() {
		add_action( 'rest_api_init', [ $this, 'register_routes' ] );
	}

	/**
	 * Register REST API routes.
	 */
	public function register_routes() {
		// Content generation endpoint
		register_rest_route( 'seo-forge/v1', '/generate', [
			'methods' => 'POST',
			'callback' => [ $this, 'generate_content' ],
			'permission_callback' => [ $this, 'check_permissions' ],
			'args' => [
				'keywords' => [
					'required' => true,
					'type' => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				],
				'content_type' => [
					'type' => 'string',
					'default' => 'blog_post',
					'sanitize_callback' => 'sanitize_text_field',
				],
				'language' => [
					'type' => 'string',
					'default' => 'en',
					'sanitize_callback' => 'sanitize_text_field',
				],
			],
		] );

		// SEO analysis endpoint
		register_rest_route( 'seo-forge/v1', '/analyze', [
			'methods' => 'POST',
			'callback' => [ $this, 'analyze_seo' ],
			'permission_callback' => [ $this, 'check_permissions' ],
			'args' => [
				'content' => [
					'required' => true,
					'type' => 'string',
					'sanitize_callback' => 'wp_kses_post',
				],
				'title' => [
					'type' => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				],
				'focus_keyword' => [
					'type' => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				],
			],
		] );

		// Keyword research endpoint
		register_rest_route( 'seo-forge/v1', '/keywords', [
			'methods' => 'POST',
			'callback' => [ $this, 'research_keywords' ],
			'permission_callback' => [ $this, 'check_permissions' ],
			'args' => [
				'seed_keywords' => [
					'required' => true,
					'type' => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				],
				'language' => [
					'type' => 'string',
					'default' => 'en',
					'sanitize_callback' => 'sanitize_text_field',
				],
				'country' => [
					'type' => 'string',
					'default' => 'US',
					'sanitize_callback' => 'sanitize_text_field',
				],
			],
		] );

		// Image generation endpoint
		register_rest_route( 'seo-forge/v1', '/image', [
			'methods' => 'POST',
			'callback' => [ $this, 'generate_image' ],
			'permission_callback' => [ $this, 'check_permissions' ],
			'args' => [
				'prompt' => [
					'required' => true,
					'type' => 'string',
					'sanitize_callback' => 'sanitize_text_field',
				],
				'style' => [
					'type' => 'string',
					'default' => 'realistic',
					'sanitize_callback' => 'sanitize_text_field',
				],
				'size' => [
					'type' => 'string',
					'default' => '1024x1024',
					'sanitize_callback' => 'sanitize_text_field',
				],
			],
		] );

		// Analytics endpoint
		register_rest_route( 'seo-forge/v1', '/analytics', [
			'methods' => 'GET',
			'callback' => [ $this, 'get_analytics' ],
			'permission_callback' => [ $this, 'check_admin_permissions' ],
			'args' => [
				'period' => [
					'type' => 'string',
					'default' => '30d',
					'sanitize_callback' => 'sanitize_text_field',
				],
				'post_id' => [
					'type' => 'integer',
					'sanitize_callback' => 'absint',
				],
			],
		] );

		// Settings endpoint
		register_rest_route( 'seo-forge/v1', '/settings', [
			[
				'methods' => 'GET',
				'callback' => [ $this, 'get_settings' ],
				'permission_callback' => [ $this, 'check_admin_permissions' ],
			],
			[
				'methods' => 'POST',
				'callback' => [ $this, 'update_settings' ],
				'permission_callback' => [ $this, 'check_admin_permissions' ],
			],
		] );

		// Status endpoint
		register_rest_route( 'seo-forge/v1', '/status', [
			'methods' => 'GET',
			'callback' => [ $this, 'get_status' ],
			'permission_callback' => [ $this, 'check_permissions' ],
		] );
	}

	/**
	 * Check permissions for general endpoints.
	 *
	 * @return bool
	 */
	public function check_permissions() {
		return current_user_can( 'edit_posts' );
	}

	/**
	 * Check permissions for admin endpoints.
	 *
	 * @return bool
	 */
	public function check_admin_permissions() {
		return current_user_can( 'manage_options' );
	}

	/**
	 * Generate content endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function generate_content( $request ) {
		$params = $request->get_params();
		
		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->generate_content( $params );

		if ( is_wp_error( $result ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => $result->get_error_message(),
			], 400 );
		}

		return new \WP_REST_Response( [
			'success' => true,
			'data' => $result,
		], 200 );
	}

	/**
	 * Analyze SEO endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function analyze_seo( $request ) {
		$params = $request->get_params();
		
		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->analyze_seo( $params );

		if ( is_wp_error( $result ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => $result->get_error_message(),
			], 400 );
		}

		return new \WP_REST_Response( [
			'success' => true,
			'data' => $result,
		], 200 );
	}

	/**
	 * Research keywords endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function research_keywords( $request ) {
		$params = $request->get_params();
		
		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->research_keywords( $params );

		if ( is_wp_error( $result ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => $result->get_error_message(),
			], 400 );
		}

		return new \WP_REST_Response( [
			'success' => true,
			'data' => $result,
		], 200 );
	}

	/**
	 * Generate image endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function generate_image( $request ) {
		$params = $request->get_params();
		
		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->generate_image( $params );

		if ( is_wp_error( $result ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => $result->get_error_message(),
			], 400 );
		}

		return new \WP_REST_Response( [
			'success' => true,
			'data' => $result,
		], 200 );
	}

	/**
	 * Get analytics endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function get_analytics( $request ) {
		$params = $request->get_params();
		
		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->get_analytics( $params );

		if ( is_wp_error( $result ) ) {
			return new \WP_REST_Response( [
				'success' => false,
				'message' => $result->get_error_message(),
			], 400 );
		}

		return new \WP_REST_Response( [
			'success' => true,
			'data' => $result,
		], 200 );
	}

	/**
	 * Get settings endpoint.
	 *
	 * @return WP_REST_Response
	 */
	public function get_settings() {
		$settings = [
			'api_url' => Helper::get_api_url(),
			'default_language' => Helper::get_default_language(),
			'auto_generate' => get_option( 'seo_forge_auto_generate', false ),
			'enable_analytics' => get_option( 'seo_forge_enable_analytics', true ),
			'enable_content_ai' => get_option( 'seo_forge_enable_content_ai', true ),
			'enable_keyword_research' => get_option( 'seo_forge_enable_keyword_research', true ),
		];

		return new \WP_REST_Response( [
			'success' => true,
			'data' => $settings,
		], 200 );
	}

	/**
	 * Update settings endpoint.
	 *
	 * @param WP_REST_Request $request Request object.
	 * @return WP_REST_Response
	 */
	public function update_settings( $request ) {
		$params = $request->get_params();

		$allowed_settings = [
			'seo_forge_api_url',
			'seo_forge_api_key',
			'seo_forge_default_language',
			'seo_forge_auto_generate',
			'seo_forge_enable_analytics',
			'seo_forge_enable_content_ai',
			'seo_forge_enable_keyword_research',
		];

		foreach ( $params as $key => $value ) {
			$option_key = 'seo_forge_' . $key;
			
			if ( in_array( $option_key, $allowed_settings, true ) ) {
				if ( $key === 'api_url' ) {
					$value = sanitize_url( $value );
				} elseif ( in_array( $key, [ 'auto_generate', 'enable_analytics', 'enable_content_ai', 'enable_keyword_research' ], true ) ) {
					$value = (bool) $value;
				} else {
					$value = sanitize_text_field( $value );
				}
				
				update_option( $option_key, $value );
			}
		}

		return new \WP_REST_Response( [
			'success' => true,
			'message' => __( 'Settings updated successfully.', 'seo-forge' ),
		], 200 );
	}

	/**
	 * Get status endpoint.
	 *
	 * @return WP_REST_Response
	 */
	public function get_status() {
		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$api_status = $mcp_client->get_api_status();

		$status = [
			'plugin_version' => SEO_FORGE_VERSION,
			'wordpress_version' => get_bloginfo( 'version' ),
			'api_status' => $api_status,
			'active_modules' => get_option( 'seo_forge_active_modules', [] ),
			'site_info' => [
				'name' => get_bloginfo( 'name' ),
				'url' => get_site_url(),
				'language' => get_locale(),
			],
		];

		return new \WP_REST_Response( [
			'success' => true,
			'data' => $status,
		], 200 );
	}
}