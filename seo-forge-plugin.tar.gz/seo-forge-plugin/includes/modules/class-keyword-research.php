<?php
/**
 * SEO Forge Keyword Research Module
 *
 * @package SEO_FORGE
 */

namespace SEOForge\Modules;

use SEOForge\Helper;

defined( 'ABSPATH' ) || exit;

/**
 * Keyword Research module.
 */
class Keyword_Research {

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! Helper::is_module_active( 'keyword-research' ) ) {
			return;
		}

		add_action( 'wp_ajax_seo_forge_research_keywords', [ $this, 'ajax_research_keywords' ] );
		add_action( 'wp_ajax_seo_forge_save_keyword', [ $this, 'ajax_save_keyword' ] );
		add_action( 'wp_ajax_seo_forge_get_keyword_suggestions', [ $this, 'ajax_get_keyword_suggestions' ] );
		
		// Schedule keyword data updates
		add_action( 'seo_forge_update_keyword_data', [ $this, 'update_keyword_data' ] );
		
		if ( ! wp_next_scheduled( 'seo_forge_update_keyword_data' ) ) {
			wp_schedule_event( time(), 'daily', 'seo_forge_update_keyword_data' );
		}
	}

	/**
	 * AJAX handler for keyword research.
	 */
	public function ajax_research_keywords() {
		check_ajax_referer( 'seo_forge_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'seo-forge' ) );
		}

		$seed_keywords = sanitize_text_field( $_POST['seed_keywords'] ?? '' );
		$language = sanitize_text_field( $_POST['language'] ?? Helper::get_default_language() );
		$country = sanitize_text_field( $_POST['country'] ?? 'US' );
		$limit = absint( $_POST['limit'] ?? 50 );

		if ( empty( $seed_keywords ) ) {
			wp_send_json_error( __( 'Seed keywords are required.', 'seo-forge' ) );
		}

		$params = [
			'seed_keywords' => $seed_keywords,
			'language' => $language,
			'country' => $country,
			'limit' => $limit,
			'include_metrics' => true,
			'include_related' => true,
			'include_questions' => true,
		];

		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->research_keywords( $params );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		// Save keywords to database
		if ( isset( $result['keywords'] ) && is_array( $result['keywords'] ) ) {
			$this->save_keywords_to_database( $result['keywords'], $language, $country );
		}

		wp_send_json_success( $result );
	}

	/**
	 * AJAX handler for saving individual keyword.
	 */
	public function ajax_save_keyword() {
		check_ajax_referer( 'seo_forge_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'seo-forge' ) );
		}

		$keyword = sanitize_text_field( $_POST['keyword'] ?? '' );
		$post_id = absint( $_POST['post_id'] ?? 0 );
		$search_volume = absint( $_POST['search_volume'] ?? 0 );
		$difficulty = absint( $_POST['difficulty'] ?? 0 );
		$cpc = floatval( $_POST['cpc'] ?? 0 );

		if ( empty( $keyword ) ) {
			wp_send_json_error( __( 'Keyword is required.', 'seo-forge' ) );
		}

		$keyword_data = [
			'keyword' => $keyword,
			'post_id' => $post_id ?: null,
			'search_volume' => $search_volume,
			'difficulty' => $difficulty,
			'cpc' => $cpc,
			'language' => Helper::get_default_language(),
			'country' => 'US',
		];

		$saved = $this->save_keyword( $keyword_data );

		if ( $saved ) {
			wp_send_json_success( __( 'Keyword saved successfully.', 'seo-forge' ) );
		} else {
			wp_send_json_error( __( 'Failed to save keyword.', 'seo-forge' ) );
		}
	}

	/**
	 * AJAX handler for getting keyword suggestions.
	 */
	public function ajax_get_keyword_suggestions() {
		check_ajax_referer( 'seo_forge_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'seo-forge' ) );
		}

		$content = wp_kses_post( $_POST['content'] ?? '' );
		$title = sanitize_text_field( $_POST['title'] ?? '' );
		$industry = sanitize_text_field( $_POST['industry'] ?? '' );

		$suggestions = $this->get_keyword_suggestions_from_content( $content, $title, $industry );

		wp_send_json_success( [ 'suggestions' => $suggestions ] );
	}

	/**
	 * Save keywords to database.
	 *
	 * @param array  $keywords Keywords data.
	 * @param string $language Language code.
	 * @param string $country Country code.
	 */
	private function save_keywords_to_database( $keywords, $language, $country ) {
		global $wpdb;

		$table_name = $wpdb->prefix . 'seo_forge_keywords';

		foreach ( $keywords as $keyword_data ) {
			$data = [
				'keyword' => $keyword_data['keyword'] ?? '',
				'search_volume' => $keyword_data['search_volume'] ?? 0,
				'difficulty' => $keyword_data['difficulty'] ?? 0,
				'cpc' => $keyword_data['cpc'] ?? 0.00,
				'competition' => $keyword_data['competition'] ?? '',
				'language' => $language,
				'country' => $country,
				'created_at' => current_time( 'mysql' ),
				'updated_at' => current_time( 'mysql' ),
			];

			$wpdb->replace( $table_name, $data );
		}
	}

	/**
	 * Save individual keyword.
	 *
	 * @param array $keyword_data Keyword data.
	 * @return bool
	 */
	private function save_keyword( $keyword_data ) {
		global $wpdb;

		$table_name = $wpdb->prefix . 'seo_forge_keywords';

		$data = array_merge( $keyword_data, [
			'created_at' => current_time( 'mysql' ),
			'updated_at' => current_time( 'mysql' ),
		] );

		$result = $wpdb->replace( $table_name, $data );

		return $result !== false;
	}

	/**
	 * Get keyword suggestions from content.
	 *
	 * @param string $content Content.
	 * @param string $title Title.
	 * @param string $industry Industry.
	 * @return array
	 */
	private function get_keyword_suggestions_from_content( $content, $title, $industry ) {
		$text = $title . ' ' . strip_tags( $content );
		$words = str_word_count( $text, 1 );
		
		// Remove common stop words
		$stop_words = [
			'the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for', 'of', 'with', 'by',
			'is', 'are', 'was', 'were', 'be', 'been', 'being', 'have', 'has', 'had', 'do', 'does', 'did',
			'will', 'would', 'could', 'should', 'may', 'might', 'must', 'can', 'this', 'that', 'these', 'those',
		];

		$words = array_filter( $words, function( $word ) use ( $stop_words ) {
			return strlen( $word ) > 2 && ! in_array( strtolower( $word ), $stop_words, true );
		} );

		// Count word frequency
		$word_counts = array_count_values( array_map( 'strtolower', $words ) );
		arsort( $word_counts );

		// Get top words
		$suggestions = [];
		$count = 0;
		foreach ( $word_counts as $word => $frequency ) {
			if ( $count >= 10 ) {
				break;
			}

			$suggestions[] = [
				'keyword' => $word,
				'frequency' => $frequency,
				'type' => 'content_based',
			];
			$count++;
		}

		// Add industry-specific suggestions if available
		if ( $industry ) {
			$industry_keywords = $this->get_industry_keywords( $industry );
			foreach ( $industry_keywords as $keyword ) {
				$suggestions[] = [
					'keyword' => $keyword,
					'frequency' => 0,
					'type' => 'industry_based',
				];
			}
		}

		return $suggestions;
	}

	/**
	 * Get industry-specific keywords.
	 *
	 * @param string $industry Industry.
	 * @return array
	 */
	private function get_industry_keywords( $industry ) {
		$industry_keywords = [
			'technology' => [
				'software', 'app', 'digital', 'innovation', 'tech', 'development', 'programming',
				'artificial intelligence', 'machine learning', 'cloud computing', 'cybersecurity',
			],
			'healthcare' => [
				'medical', 'health', 'treatment', 'doctor', 'patient', 'medicine', 'therapy',
				'diagnosis', 'wellness', 'healthcare', 'clinical', 'pharmaceutical',
			],
			'finance' => [
				'money', 'investment', 'banking', 'financial', 'loan', 'credit', 'insurance',
				'wealth', 'portfolio', 'trading', 'mortgage', 'retirement',
			],
			'education' => [
				'learning', 'student', 'course', 'training', 'education', 'school', 'university',
				'online learning', 'certification', 'skill development', 'academic',
			],
			'retail' => [
				'shopping', 'product', 'sale', 'discount', 'store', 'customer', 'brand',
				'ecommerce', 'online shopping', 'fashion', 'deals', 'marketplace',
			],
		];

		return $industry_keywords[ $industry ] ?? [];
	}

	/**
	 * Get saved keywords.
	 *
	 * @param array $args Query arguments.
	 * @return array
	 */
	public function get_saved_keywords( $args = [] ) {
		global $wpdb;

		$defaults = [
			'limit' => 50,
			'offset' => 0,
			'language' => Helper::get_default_language(),
			'country' => 'US',
			'post_id' => null,
			'search' => '',
			'orderby' => 'search_volume',
			'order' => 'DESC',
		];

		$args = wp_parse_args( $args, $defaults );

		$table_name = $wpdb->prefix . 'seo_forge_keywords';
		$where_clauses = [ '1=1' ];
		$where_values = [];

		if ( $args['language'] ) {
			$where_clauses[] = 'language = %s';
			$where_values[] = $args['language'];
		}

		if ( $args['country'] ) {
			$where_clauses[] = 'country = %s';
			$where_values[] = $args['country'];
		}

		if ( $args['post_id'] ) {
			$where_clauses[] = 'post_id = %d';
			$where_values[] = $args['post_id'];
		}

		if ( $args['search'] ) {
			$where_clauses[] = 'keyword LIKE %s';
			$where_values[] = '%' . $wpdb->esc_like( $args['search'] ) . '%';
		}

		$where_clause = implode( ' AND ', $where_clauses );
		$order_clause = sprintf( 'ORDER BY %s %s', $args['orderby'], $args['order'] );
		$limit_clause = sprintf( 'LIMIT %d OFFSET %d', $args['limit'], $args['offset'] );

		$query = "SELECT * FROM $table_name WHERE $where_clause $order_clause $limit_clause";

		if ( ! empty( $where_values ) ) {
			$query = $wpdb->prepare( $query, $where_values );
		}

		return $wpdb->get_results( $query, ARRAY_A );
	}

	/**
	 * Get keyword statistics.
	 *
	 * @return array
	 */
	public function get_keyword_stats() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'seo_forge_keywords';

		$stats = [
			'total_keywords' => 0,
			'average_search_volume' => 0,
			'average_difficulty' => 0,
			'average_cpc' => 0,
			'top_keywords' => [],
			'difficulty_distribution' => [
				'easy' => 0,    // 0-30
				'medium' => 0,  // 31-60
				'hard' => 0,    // 61-100
			],
		];

		// Get total count
		$total = $wpdb->get_var( "SELECT COUNT(*) FROM $table_name" );
		$stats['total_keywords'] = (int) $total;

		if ( $total > 0 ) {
			// Get averages
			$averages = $wpdb->get_row(
				"SELECT 
					AVG(search_volume) as avg_volume,
					AVG(difficulty) as avg_difficulty,
					AVG(cpc) as avg_cpc
				FROM $table_name"
			);

			$stats['average_search_volume'] = round( $averages->avg_volume );
			$stats['average_difficulty'] = round( $averages->avg_difficulty );
			$stats['average_cpc'] = round( $averages->avg_cpc, 2 );

			// Get top keywords by search volume
			$top_keywords = $wpdb->get_results(
				"SELECT keyword, search_volume, difficulty, cpc 
				FROM $table_name 
				ORDER BY search_volume DESC 
				LIMIT 10",
				ARRAY_A
			);

			$stats['top_keywords'] = $top_keywords;

			// Get difficulty distribution
			$difficulty_counts = $wpdb->get_results(
				"SELECT 
					CASE 
						WHEN difficulty <= 30 THEN 'easy'
						WHEN difficulty <= 60 THEN 'medium'
						ELSE 'hard'
					END as difficulty_level,
					COUNT(*) as count
				FROM $table_name 
				GROUP BY difficulty_level"
			);

			foreach ( $difficulty_counts as $row ) {
				$stats['difficulty_distribution'][ $row->difficulty_level ] = (int) $row->count;
			}
		}

		return $stats;
	}

	/**
	 * Update keyword data from external sources.
	 */
	public function update_keyword_data() {
		global $wpdb;

		$table_name = $wpdb->prefix . 'seo_forge_keywords';

		// Get keywords that haven't been updated in the last 7 days
		$keywords = $wpdb->get_results(
			"SELECT * FROM $table_name 
			WHERE updated_at < DATE_SUB(NOW(), INTERVAL 7 DAY) 
			ORDER BY updated_at ASC 
			LIMIT 50"
		);

		if ( empty( $keywords ) ) {
			return;
		}

		$mcp_client = seo_forge()->get_container( 'mcp_client' );

		foreach ( $keywords as $keyword ) {
			$params = [
				'seed_keywords' => $keyword->keyword,
				'language' => $keyword->language,
				'country' => $keyword->country,
				'limit' => 1,
			];

			$result = $mcp_client->research_keywords( $params );

			if ( ! is_wp_error( $result ) && isset( $result['keywords'][0] ) ) {
				$updated_data = $result['keywords'][0];

				$wpdb->update(
					$table_name,
					[
						'search_volume' => $updated_data['search_volume'] ?? $keyword->search_volume,
						'difficulty' => $updated_data['difficulty'] ?? $keyword->difficulty,
						'cpc' => $updated_data['cpc'] ?? $keyword->cpc,
						'competition' => $updated_data['competition'] ?? $keyword->competition,
						'updated_at' => current_time( 'mysql' ),
					],
					[ 'id' => $keyword->id ]
				);
			}

			// Add small delay to avoid rate limiting
			sleep( 1 );
		}
	}

	/**
	 * Export keywords to CSV.
	 *
	 * @param array $args Query arguments.
	 * @return string CSV content.
	 */
	public function export_keywords_csv( $args = [] ) {
		$keywords = $this->get_saved_keywords( array_merge( $args, [ 'limit' => 1000 ] ) );

		$csv_content = "Keyword,Search Volume,Difficulty,CPC,Competition,Language,Country,Created At\n";

		foreach ( $keywords as $keyword ) {
			$csv_content .= sprintf(
				'"%s",%d,%d,%.2f,"%s","%s","%s","%s"' . "\n",
				$keyword['keyword'],
				$keyword['search_volume'],
				$keyword['difficulty'],
				$keyword['cpc'],
				$keyword['competition'],
				$keyword['language'],
				$keyword['country'],
				$keyword['created_at']
			);
		}

		return $csv_content;
	}
}