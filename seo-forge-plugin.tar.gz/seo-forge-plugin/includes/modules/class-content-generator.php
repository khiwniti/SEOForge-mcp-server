<?php
/**
 * SEO Forge Content Generator Module
 *
 * @package SEO_FORGE
 */

namespace SEOForge\Modules;

use SEOForge\Helper;

defined( 'ABSPATH' ) || exit;

/**
 * Content Generator module.
 */
class Content_Generator {

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! Helper::is_module_active( 'content-generator' ) ) {
			return;
		}

		add_action( 'wp_ajax_seo_forge_generate_content', [ $this, 'ajax_generate_content' ] );
		add_action( 'wp_ajax_seo_forge_generate_suggestions', [ $this, 'ajax_generate_suggestions' ] );
		add_action( 'wp_ajax_seo_forge_generate_image', [ $this, 'ajax_generate_image' ] );
		
		// Gutenberg block support
		if ( Helper::is_gutenberg_active() ) {
			add_action( 'init', [ $this, 'register_blocks' ] );
		}
	}

	/**
	 * AJAX handler for content generation.
	 */
	public function ajax_generate_content() {
		check_ajax_referer( 'seo_forge_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'seo-forge' ) );
		}

		$keywords = sanitize_text_field( $_POST['keywords'] ?? '' );
		$industry = sanitize_text_field( $_POST['industry'] ?? '' );
		$content_type = sanitize_text_field( $_POST['content_type'] ?? 'blog_post' );
		$language = sanitize_text_field( $_POST['language'] ?? Helper::get_default_language() );
		$tone = sanitize_text_field( $_POST['tone'] ?? 'professional' );
		$length = sanitize_text_field( $_POST['length'] ?? 'medium' );

		if ( empty( $keywords ) ) {
			wp_send_json_error( __( 'Keywords are required.', 'seo-forge' ) );
		}

		$params = [
			'keywords' => $keywords,
			'industry' => $industry,
			'type' => $content_type,
			'language' => $language,
			'tone' => $tone,
			'length' => $length,
			'include_title' => true,
			'include_meta_description' => true,
			'include_outline' => true,
		];

		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->generate_content( $params );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		// Save generation history
		$this->save_generation_history( $params, $result );

		wp_send_json_success( $result );
	}

	/**
	 * AJAX handler for content suggestions.
	 */
	public function ajax_generate_suggestions() {
		check_ajax_referer( 'seo_forge_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'seo-forge' ) );
		}

		$content = wp_kses_post( $_POST['content'] ?? '' );
		$keywords = sanitize_text_field( $_POST['keywords'] ?? '' );
		$suggestion_type = sanitize_text_field( $_POST['type'] ?? 'improvement' );

		$params = [
			'content' => $content,
			'keywords' => $keywords,
			'type' => $suggestion_type,
			'language' => Helper::get_default_language(),
		];

		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->get_suggestions( $params );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( $result );
	}

	/**
	 * AJAX handler for image generation.
	 */
	public function ajax_generate_image() {
		check_ajax_referer( 'seo_forge_nonce', 'nonce' );

		if ( ! current_user_can( 'upload_files' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'seo-forge' ) );
		}

		$prompt = sanitize_text_field( $_POST['prompt'] ?? '' );
		$style = sanitize_text_field( $_POST['style'] ?? 'realistic' );
		$size = sanitize_text_field( $_POST['size'] ?? '1024x1024' );

		if ( empty( $prompt ) ) {
			wp_send_json_error( __( 'Image prompt is required.', 'seo-forge' ) );
		}

		$params = [
			'prompt' => $prompt,
			'style' => $style,
			'size' => $size,
			'quality' => 'high',
		];

		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->generate_image( $params );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		// Optionally save image to media library
		if ( isset( $result['url'] ) && ! empty( $_POST['save_to_media'] ) ) {
			$media_id = $this->save_image_to_media( $result['url'], $prompt );
			if ( $media_id ) {
				$result['media_id'] = $media_id;
				$result['media_url'] = wp_get_attachment_url( $media_id );
			}
		}

		wp_send_json_success( $result );
	}

	/**
	 * Register Gutenberg blocks.
	 */
	public function register_blocks() {
		// Content Generator Block
		register_block_type( 'seo-forge/content-generator', [
			'editor_script' => 'seo-forge-blocks',
			'render_callback' => [ $this, 'render_content_generator_block' ],
			'attributes' => [
				'keywords' => [
					'type' => 'string',
					'default' => '',
				],
				'contentType' => [
					'type' => 'string',
					'default' => 'blog_post',
				],
				'language' => [
					'type' => 'string',
					'default' => Helper::get_default_language(),
				],
			],
		] );
	}

	/**
	 * Render content generator block.
	 *
	 * @param array $attributes Block attributes.
	 * @return string
	 */
	public function render_content_generator_block( $attributes ) {
		if ( ! is_admin() ) {
			return '';
		}

		$keywords = $attributes['keywords'] ?? '';
		$content_type = $attributes['contentType'] ?? 'blog_post';
		$language = $attributes['language'] ?? Helper::get_default_language();

		ob_start();
		?>
		<div class="seo-forge-content-generator-block">
			<div class="block-header">
				<h3><?php esc_html_e( 'SEO Forge Content Generator', 'seo-forge' ); ?></h3>
			</div>
			<div class="block-content">
				<input type="text" placeholder="<?php esc_attr_e( 'Enter keywords...', 'seo-forge' ); ?>" value="<?php echo esc_attr( $keywords ); ?>" class="keywords-input" />
				<select class="content-type-select">
					<option value="blog_post" <?php selected( $content_type, 'blog_post' ); ?>><?php esc_html_e( 'Blog Post', 'seo-forge' ); ?></option>
					<option value="product_description" <?php selected( $content_type, 'product_description' ); ?>><?php esc_html_e( 'Product Description', 'seo-forge' ); ?></option>
					<option value="landing_page" <?php selected( $content_type, 'landing_page' ); ?>><?php esc_html_e( 'Landing Page', 'seo-forge' ); ?></option>
				</select>
				<button type="button" class="button button-primary generate-content-btn">
					<?php esc_html_e( 'Generate Content', 'seo-forge' ); ?>
				</button>
			</div>
			<div class="generated-content-area" style="display: none;">
				<h4><?php esc_html_e( 'Generated Content', 'seo-forge' ); ?></h4>
				<div class="content-preview"></div>
				<button type="button" class="button insert-content-btn">
					<?php esc_html_e( 'Insert Content', 'seo-forge' ); ?>
				</button>
			</div>
		</div>
		<?php
		return ob_get_clean();
	}

	/**
	 * Save generation history.
	 *
	 * @param array $params Generation parameters.
	 * @param array $result Generation result.
	 */
	private function save_generation_history( $params, $result ) {
		$history = get_option( 'seo_forge_generation_history', [] );
		
		$entry = [
			'timestamp' => time(),
			'user_id' => get_current_user_id(),
			'params' => $params,
			'result' => [
				'title' => $result['title'] ?? '',
				'word_count' => str_word_count( strip_tags( $result['content'] ?? '' ) ),
				'success' => true,
			],
		];

		// Keep only last 100 entries
		array_unshift( $history, $entry );
		$history = array_slice( $history, 0, 100 );

		update_option( 'seo_forge_generation_history', $history );
	}

	/**
	 * Save generated image to media library.
	 *
	 * @param string $image_url Image URL.
	 * @param string $description Image description.
	 * @return int|false Media ID or false on failure.
	 */
	private function save_image_to_media( $image_url, $description ) {
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		// Download image
		$temp_file = download_url( $image_url );
		if ( is_wp_error( $temp_file ) ) {
			return false;
		}

		// Prepare file array
		$file_array = [
			'name' => 'seo-forge-generated-' . time() . '.png',
			'tmp_name' => $temp_file,
		];

		// Upload to media library
		$media_id = media_handle_sideload( $file_array, 0, $description );

		// Clean up temp file
		if ( ! is_wp_error( $media_id ) ) {
			unlink( $temp_file );
		}

		return is_wp_error( $media_id ) ? false : $media_id;
	}

	/**
	 * Get content templates.
	 *
	 * @return array
	 */
	public function get_content_templates() {
		return [
			'blog_post' => [
				'name' => __( 'Blog Post', 'seo-forge' ),
				'structure' => [
					'introduction',
					'main_content',
					'conclusion',
					'call_to_action',
				],
			],
			'product_description' => [
				'name' => __( 'Product Description', 'seo-forge' ),
				'structure' => [
					'headline',
					'features',
					'benefits',
					'specifications',
				],
			],
			'landing_page' => [
				'name' => __( 'Landing Page', 'seo-forge' ),
				'structure' => [
					'hero_section',
					'value_proposition',
					'features',
					'testimonials',
					'call_to_action',
				],
			],
			'how_to_guide' => [
				'name' => __( 'How-to Guide', 'seo-forge' ),
				'structure' => [
					'introduction',
					'prerequisites',
					'step_by_step',
					'conclusion',
				],
			],
		];
	}

	/**
	 * Get generation statistics.
	 *
	 * @return array
	 */
	public function get_generation_stats() {
		$history = get_option( 'seo_forge_generation_history', [] );
		
		$stats = [
			'total_generations' => count( $history ),
			'this_month' => 0,
			'this_week' => 0,
			'today' => 0,
			'average_word_count' => 0,
			'popular_types' => [],
		];

		$now = time();
		$month_start = strtotime( 'first day of this month' );
		$week_start = strtotime( 'monday this week' );
		$day_start = strtotime( 'today' );

		$word_counts = [];
		$types = [];

		foreach ( $history as $entry ) {
			$timestamp = $entry['timestamp'];
			
			if ( $timestamp >= $month_start ) {
				$stats['this_month']++;
			}
			
			if ( $timestamp >= $week_start ) {
				$stats['this_week']++;
			}
			
			if ( $timestamp >= $day_start ) {
				$stats['today']++;
			}

			if ( isset( $entry['result']['word_count'] ) ) {
				$word_counts[] = $entry['result']['word_count'];
			}

			$type = $entry['params']['type'] ?? 'unknown';
			$types[ $type ] = ( $types[ $type ] ?? 0 ) + 1;
		}

		if ( ! empty( $word_counts ) ) {
			$stats['average_word_count'] = round( array_sum( $word_counts ) / count( $word_counts ) );
		}

		arsort( $types );
		$stats['popular_types'] = array_slice( $types, 0, 5, true );

		return $stats;
	}
}