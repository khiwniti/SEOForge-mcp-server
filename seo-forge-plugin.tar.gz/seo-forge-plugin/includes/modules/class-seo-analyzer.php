<?php
/**
 * SEO Forge SEO Analyzer Module
 *
 * @package SEO_FORGE
 */

namespace SEOForge\Modules;

use SEOForge\Helper;

defined( 'ABSPATH' ) || exit;

/**
 * SEO Analyzer module.
 */
class SEO_Analyzer {

	/**
	 * Constructor.
	 */
	public function __construct() {
		if ( ! Helper::is_module_active( 'seo-analyzer' ) ) {
			return;
		}

		add_action( 'wp_ajax_seo_forge_analyze_seo', [ $this, 'ajax_analyze_seo' ] );
		add_action( 'wp_ajax_seo_forge_optimize_content', [ $this, 'ajax_optimize_content' ] );
		add_action( 'save_post', [ $this, 'auto_analyze_post' ], 20 );
		
		// Add SEO score column to post list
		add_filter( 'manage_posts_columns', [ $this, 'add_seo_score_column' ] );
		add_action( 'manage_posts_custom_column', [ $this, 'display_seo_score_column' ], 10, 2 );
	}

	/**
	 * AJAX handler for SEO analysis.
	 */
	public function ajax_analyze_seo() {
		check_ajax_referer( 'seo_forge_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'seo-forge' ) );
		}

		$title = sanitize_text_field( $_POST['title'] ?? '' );
		$content = wp_kses_post( $_POST['content'] ?? '' );
		$meta_description = sanitize_text_field( $_POST['meta_description'] ?? '' );
		$focus_keyword = sanitize_text_field( $_POST['focus_keyword'] ?? '' );
		$url = esc_url_raw( $_POST['url'] ?? '' );
		$post_id = absint( $_POST['post_id'] ?? 0 );

		$params = [
			'title' => $title,
			'content' => $content,
			'meta_description' => $meta_description,
			'focus_keyword' => $focus_keyword,
			'url' => $url,
			'language' => Helper::get_default_language(),
			'check_readability' => true,
			'check_keywords' => true,
			'check_meta' => true,
			'check_structure' => true,
		];

		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->analyze_seo( $params );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		// Save analysis results
		if ( $post_id ) {
			$this->save_analysis_results( $post_id, $result );
		}

		wp_send_json_success( $result );
	}

	/**
	 * AJAX handler for content optimization.
	 */
	public function ajax_optimize_content() {
		check_ajax_referer( 'seo_forge_nonce', 'nonce' );

		if ( ! current_user_can( 'edit_posts' ) ) {
			wp_send_json_error( __( 'Insufficient permissions.', 'seo-forge' ) );
		}

		$title = sanitize_text_field( $_POST['title'] ?? '' );
		$content = wp_kses_post( $_POST['content'] ?? '' );
		$focus_keyword = sanitize_text_field( $_POST['focus_keyword'] ?? '' );
		$optimization_type = sanitize_text_field( $_POST['optimization_type'] ?? 'seo' );

		$params = [
			'title' => $title,
			'content' => $content,
			'focus_keyword' => $focus_keyword,
			'optimization_type' => $optimization_type,
			'language' => Helper::get_default_language(),
		];

		$mcp_client = seo_forge()->get_container( 'mcp_client' );
		$result = $mcp_client->optimize_content( $params );

		if ( is_wp_error( $result ) ) {
			wp_send_json_error( $result->get_error_message() );
		}

		wp_send_json_success( $result );
	}

	/**
	 * Auto-analyze post on save.
	 *
	 * @param int $post_id Post ID.
	 */
	public function auto_analyze_post( $post_id ) {
		if ( ! get_option( 'seo_forge_auto_analyze', false ) ) {
			return;
		}

		if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
			return;
		}

		$post = get_post( $post_id );
		if ( ! $post || $post->post_status !== 'publish' ) {
			return;
		}

		// Schedule analysis to avoid slowing down the save process
		wp_schedule_single_event( time() + 30, 'seo_forge_analyze_post', [ $post_id ] );
	}

	/**
	 * Add SEO score column to post list.
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function add_seo_score_column( $columns ) {
		$columns['seo_forge_score'] = __( 'SEO Score', 'seo-forge' );
		return $columns;
	}

	/**
	 * Display SEO score in post list column.
	 *
	 * @param string $column_name Column name.
	 * @param int    $post_id Post ID.
	 */
	public function display_seo_score_column( $column_name, $post_id ) {
		if ( $column_name !== 'seo_forge_score' ) {
			return;
		}

		$score = get_post_meta( $post_id, '_seo_forge_seo_score', true );
		
		if ( $score ) {
			$score_class = 'poor';
			if ( $score >= 80 ) {
				$score_class = 'excellent';
			} elseif ( $score >= 60 ) {
				$score_class = 'good';
			} elseif ( $score >= 40 ) {
				$score_class = 'fair';
			}

			echo '<span class="seo-forge-score-badge ' . esc_attr( $score_class ) . '">' . esc_html( $score ) . '</span>';
		} else {
			echo '<span class="seo-forge-score-badge not-analyzed">' . esc_html__( 'Not analyzed', 'seo-forge' ) . '</span>';
		}
	}

	/**
	 * Save analysis results.
	 *
	 * @param int   $post_id Post ID.
	 * @param array $results Analysis results.
	 */
	private function save_analysis_results( $post_id, $results ) {
		update_post_meta( $post_id, '_seo_forge_last_analysis', current_time( 'mysql' ) );
		update_post_meta( $post_id, '_seo_forge_seo_score', $results['score'] ?? 0 );
		update_post_meta( $post_id, '_seo_forge_analysis_results', $results );

		// Save individual metrics
		if ( isset( $results['metrics'] ) ) {
			foreach ( $results['metrics'] as $metric => $value ) {
				update_post_meta( $post_id, '_seo_forge_metric_' . $metric, $value );
			}
		}

		// Save issues and recommendations
		if ( isset( $results['issues'] ) ) {
			update_post_meta( $post_id, '_seo_forge_issues', $results['issues'] );
		}

		if ( isset( $results['recommendations'] ) ) {
			update_post_meta( $post_id, '_seo_forge_recommendations', $results['recommendations'] );
		}
	}

	/**
	 * Perform local SEO checks.
	 *
	 * @param array $params Analysis parameters.
	 * @return array
	 */
	public function perform_local_checks( $params ) {
		$checks = [];
		$score = 0;
		$max_score = 0;

		// Title check
		$title = $params['title'] ?? '';
		$title_length = strlen( $title );
		$max_score += 20;

		if ( empty( $title ) ) {
			$checks[] = [
				'type' => 'error',
				'message' => __( 'SEO title is missing.', 'seo-forge' ),
				'severity' => 'high',
			];
		} elseif ( $title_length < 30 ) {
			$checks[] = [
				'type' => 'warning',
				'message' => __( 'SEO title is too short. Consider making it longer.', 'seo-forge' ),
				'severity' => 'medium',
			];
			$score += 10;
		} elseif ( $title_length > 60 ) {
			$checks[] = [
				'type' => 'warning',
				'message' => __( 'SEO title is too long. It may be truncated in search results.', 'seo-forge' ),
				'severity' => 'medium',
			];
			$score += 15;
		} else {
			$checks[] = [
				'type' => 'success',
				'message' => __( 'SEO title length is optimal.', 'seo-forge' ),
				'severity' => 'low',
			];
			$score += 20;
		}

		// Meta description check
		$description = $params['meta_description'] ?? '';
		$description_length = strlen( $description );
		$max_score += 20;

		if ( empty( $description ) ) {
			$checks[] = [
				'type' => 'error',
				'message' => __( 'Meta description is missing.', 'seo-forge' ),
				'severity' => 'high',
			];
		} elseif ( $description_length < 120 ) {
			$checks[] = [
				'type' => 'warning',
				'message' => __( 'Meta description is too short.', 'seo-forge' ),
				'severity' => 'medium',
			];
			$score += 10;
		} elseif ( $description_length > 160 ) {
			$checks[] = [
				'type' => 'warning',
				'message' => __( 'Meta description is too long.', 'seo-forge' ),
				'severity' => 'medium',
			];
			$score += 15;
		} else {
			$checks[] = [
				'type' => 'success',
				'message' => __( 'Meta description length is optimal.', 'seo-forge' ),
				'severity' => 'low',
			];
			$score += 20;
		}

		// Focus keyword check
		$focus_keyword = $params['focus_keyword'] ?? '';
		$content = $params['content'] ?? '';
		$max_score += 30;

		if ( empty( $focus_keyword ) ) {
			$checks[] = [
				'type' => 'warning',
				'message' => __( 'No focus keyword set.', 'seo-forge' ),
				'severity' => 'medium',
			];
		} else {
			$keyword_in_title = stripos( $title, $focus_keyword ) !== false;
			$keyword_in_description = stripos( $description, $focus_keyword ) !== false;
			$keyword_in_content = stripos( $content, $focus_keyword ) !== false;

			if ( $keyword_in_title && $keyword_in_description && $keyword_in_content ) {
				$checks[] = [
					'type' => 'success',
					'message' => __( 'Focus keyword appears in title, description, and content.', 'seo-forge' ),
					'severity' => 'low',
				];
				$score += 30;
			} elseif ( $keyword_in_title && $keyword_in_content ) {
				$checks[] = [
					'type' => 'warning',
					'message' => __( 'Focus keyword appears in title and content but not in meta description.', 'seo-forge' ),
					'severity' => 'medium',
				];
				$score += 20;
			} elseif ( $keyword_in_content ) {
				$checks[] = [
					'type' => 'warning',
					'message' => __( 'Focus keyword appears in content but not in title or meta description.', 'seo-forge' ),
					'severity' => 'medium',
				];
				$score += 15;
			} else {
				$checks[] = [
					'type' => 'error',
					'message' => __( 'Focus keyword does not appear in title, description, or content.', 'seo-forge' ),
					'severity' => 'high',
				];
			}
		}

		// Content length check
		$content_text = strip_tags( $content );
		$word_count = str_word_count( $content_text );
		$max_score += 15;

		if ( $word_count < 300 ) {
			$checks[] = [
				'type' => 'warning',
				'message' => sprintf( __( 'Content is too short (%d words). Consider adding more content.', 'seo-forge' ), $word_count ),
				'severity' => 'medium',
			];
			$score += 5;
		} elseif ( $word_count < 500 ) {
			$checks[] = [
				'type' => 'info',
				'message' => sprintf( __( 'Content length is acceptable (%d words).', 'seo-forge' ), $word_count ),
				'severity' => 'low',
			];
			$score += 10;
		} else {
			$checks[] = [
				'type' => 'success',
				'message' => sprintf( __( 'Content length is good (%d words).', 'seo-forge' ), $word_count ),
				'severity' => 'low',
			];
			$score += 15;
		}

		// Heading structure check
		$max_score += 15;
		$h1_count = preg_match_all( '/<h1[^>]*>/i', $content );
		$h2_count = preg_match_all( '/<h2[^>]*>/i', $content );

		if ( $h1_count === 0 ) {
			$checks[] = [
				'type' => 'warning',
				'message' => __( 'No H1 heading found in content.', 'seo-forge' ),
				'severity' => 'medium',
			];
			$score += 5;
		} elseif ( $h1_count > 1 ) {
			$checks[] = [
				'type' => 'warning',
				'message' => __( 'Multiple H1 headings found. Use only one H1 per page.', 'seo-forge' ),
				'severity' => 'medium',
			];
			$score += 10;
		} else {
			$checks[] = [
				'type' => 'success',
				'message' => __( 'Proper H1 heading structure.', 'seo-forge' ),
				'severity' => 'low',
			];
			$score += 15;
		}

		if ( $h2_count === 0 && $word_count > 500 ) {
			$checks[] = [
				'type' => 'info',
				'message' => __( 'Consider adding H2 headings to improve content structure.', 'seo-forge' ),
				'severity' => 'low',
			];
		}

		// Calculate final score
		$final_score = $max_score > 0 ? round( ( $score / $max_score ) * 100 ) : 0;

		return [
			'score' => $final_score,
			'checks' => $checks,
			'metrics' => [
				'title_length' => $title_length,
				'description_length' => $description_length,
				'word_count' => $word_count,
				'h1_count' => $h1_count,
				'h2_count' => $h2_count,
			],
		];
	}

	/**
	 * Get SEO analysis statistics.
	 *
	 * @return array
	 */
	public function get_analysis_stats() {
		global $wpdb;

		$stats = [
			'total_analyzed' => 0,
			'average_score' => 0,
			'score_distribution' => [
				'excellent' => 0, // 80-100
				'good' => 0,      // 60-79
				'fair' => 0,      // 40-59
				'poor' => 0,      // 0-39
			],
			'common_issues' => [],
		];

		// Get all analyzed posts
		$results = $wpdb->get_results(
			"SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_seo_forge_seo_score'"
		);

		if ( empty( $results ) ) {
			return $stats;
		}

		$scores = array_map( 'intval', wp_list_pluck( $results, 'meta_value' ) );
		$stats['total_analyzed'] = count( $scores );
		$stats['average_score'] = round( array_sum( $scores ) / count( $scores ) );

		// Calculate score distribution
		foreach ( $scores as $score ) {
			if ( $score >= 80 ) {
				$stats['score_distribution']['excellent']++;
			} elseif ( $score >= 60 ) {
				$stats['score_distribution']['good']++;
			} elseif ( $score >= 40 ) {
				$stats['score_distribution']['fair']++;
			} else {
				$stats['score_distribution']['poor']++;
			}
		}

		return $stats;
	}
}