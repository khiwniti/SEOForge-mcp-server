<?php
/**
 * SEO Forge Installer Class
 *
 * @package SEO_FORGE
 */

namespace SEOForge;

defined( 'ABSPATH' ) || exit;

/**
 * Installer class.
 */
class Installer {

	/**
	 * Plugin activation.
	 */
	public static function activate() {
		self::create_tables();
		self::create_options();
		self::schedule_events();
		self::create_files();
	}

	/**
	 * Create database tables.
	 */
	private static function create_tables() {
		global $wpdb;

		$charset_collate = $wpdb->get_charset_collate();

		// Analytics table
		$analytics_table = $wpdb->prefix . 'seo_forge_analytics';
		$analytics_sql = "CREATE TABLE $analytics_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			post_id bigint(20) NOT NULL,
			date date NOT NULL,
			impressions int(11) DEFAULT 0,
			clicks int(11) DEFAULT 0,
			ctr decimal(5,2) DEFAULT 0.00,
			position decimal(5,2) DEFAULT 0.00,
			keyword varchar(255) DEFAULT '',
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY post_id (post_id),
			KEY date (date),
			KEY keyword (keyword)
		) $charset_collate;";

		// Keywords table
		$keywords_table = $wpdb->prefix . 'seo_forge_keywords';
		$keywords_sql = "CREATE TABLE $keywords_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			keyword varchar(255) NOT NULL,
			post_id bigint(20) DEFAULT NULL,
			search_volume int(11) DEFAULT 0,
			difficulty int(3) DEFAULT 0,
			cpc decimal(10,2) DEFAULT 0.00,
			competition varchar(20) DEFAULT '',
			language varchar(10) DEFAULT 'en',
			country varchar(10) DEFAULT 'US',
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			UNIQUE KEY keyword_lang_country (keyword, language, country),
			KEY post_id (post_id)
		) $charset_collate;";

		// Content suggestions table
		$suggestions_table = $wpdb->prefix . 'seo_forge_suggestions';
		$suggestions_sql = "CREATE TABLE $suggestions_table (
			id bigint(20) NOT NULL AUTO_INCREMENT,
			post_id bigint(20) NOT NULL,
			type varchar(50) NOT NULL,
			suggestion text NOT NULL,
			priority int(3) DEFAULT 5,
			status varchar(20) DEFAULT 'pending',
			created_at datetime DEFAULT CURRENT_TIMESTAMP,
			updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
			PRIMARY KEY (id),
			KEY post_id (post_id),
			KEY type (type),
			KEY status (status)
		) $charset_collate;";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $analytics_sql );
		dbDelta( $keywords_sql );
		dbDelta( $suggestions_sql );
	}

	/**
	 * Create default options.
	 */
	private static function create_options() {
		$options = [
			'seo_forge_version' => SEO_FORGE_VERSION,
			'seo_forge_api_url' => 'https://seoforge-mcp-platform.vercel.app',
			'seo_forge_api_key' => '',
			'seo_forge_default_language' => 'en',
			'seo_forge_auto_generate' => false,
			'seo_forge_enable_analytics' => true,
			'seo_forge_enable_content_ai' => true,
			'seo_forge_enable_keyword_research' => true,
			'seo_forge_active_modules' => [
				'content-generator',
				'seo-analyzer',
				'keyword-research',
				'meta-tags',
				'schema',
				'sitemap',
			],
			'seo_forge_homepage_title' => '',
			'seo_forge_homepage_description' => '',
			'seo_forge_homepage_keywords' => '',
			'seo_forge_twitter_handle' => '',
			'seo_forge_facebook_app_id' => '',
			'seo_forge_google_analytics_id' => '',
			'seo_forge_google_search_console' => '',
			'seo_forge_bing_webmaster' => '',
			'seo_forge_yandex_verification' => '',
			'seo_forge_pinterest_verification' => '',
		];

		foreach ( $options as $option => $value ) {
			if ( false === get_option( $option ) ) {
				add_option( $option, $value );
			}
		}
	}

	/**
	 * Schedule events.
	 */
	private static function schedule_events() {
		// Schedule daily analytics sync
		if ( ! wp_next_scheduled( 'seo_forge_daily_analytics_sync' ) ) {
			wp_schedule_event( time(), 'daily', 'seo_forge_daily_analytics_sync' );
		}

		// Schedule weekly keyword research
		if ( ! wp_next_scheduled( 'seo_forge_weekly_keyword_research' ) ) {
			wp_schedule_event( time(), 'weekly', 'seo_forge_weekly_keyword_research' );
		}
	}

	/**
	 * Create necessary files.
	 */
	private static function create_files() {
		// Create uploads directory for SEO Forge
		$upload_dir = wp_upload_dir();
		$seo_forge_dir = $upload_dir['basedir'] . '/seo-forge';

		if ( ! file_exists( $seo_forge_dir ) ) {
			wp_mkdir_p( $seo_forge_dir );
		}

		// Create .htaccess file for security
		$htaccess_file = $seo_forge_dir . '/.htaccess';
		if ( ! file_exists( $htaccess_file ) ) {
			$htaccess_content = "# SEO Forge Security\n";
			$htaccess_content .= "Options -Indexes\n";
			$htaccess_content .= "<Files *.php>\n";
			$htaccess_content .= "deny from all\n";
			$htaccess_content .= "</Files>\n";
			
			file_put_contents( $htaccess_file, $htaccess_content );
		}

		// Create index.php file for security
		$index_file = $seo_forge_dir . '/index.php';
		if ( ! file_exists( $index_file ) ) {
			file_put_contents( $index_file, "<?php\n// Silence is golden.\n" );
		}
	}

	/**
	 * Plugin deactivation.
	 */
	public static function deactivate() {
		// Clear scheduled events
		wp_clear_scheduled_hook( 'seo_forge_daily_analytics_sync' );
		wp_clear_scheduled_hook( 'seo_forge_weekly_keyword_research' );
	}

	/**
	 * Plugin uninstall.
	 */
	public static function uninstall() {
		global $wpdb;

		// Remove tables
		$tables = [
			$wpdb->prefix . 'seo_forge_analytics',
			$wpdb->prefix . 'seo_forge_keywords',
			$wpdb->prefix . 'seo_forge_suggestions',
		];

		foreach ( $tables as $table ) {
			$wpdb->query( "DROP TABLE IF EXISTS $table" );
		}

		// Remove options
		$options = [
			'seo_forge_version',
			'seo_forge_api_url',
			'seo_forge_api_key',
			'seo_forge_default_language',
			'seo_forge_auto_generate',
			'seo_forge_enable_analytics',
			'seo_forge_enable_content_ai',
			'seo_forge_enable_keyword_research',
			'seo_forge_active_modules',
			'seo_forge_homepage_title',
			'seo_forge_homepage_description',
			'seo_forge_homepage_keywords',
			'seo_forge_twitter_handle',
			'seo_forge_facebook_app_id',
			'seo_forge_google_analytics_id',
			'seo_forge_google_search_console',
			'seo_forge_bing_webmaster',
			'seo_forge_yandex_verification',
			'seo_forge_pinterest_verification',
		];

		foreach ( $options as $option ) {
			delete_option( $option );
		}

		// Remove post meta
		$wpdb->query( "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '_seo_forge_%'" );

		// Remove term meta
		$wpdb->query( "DELETE FROM {$wpdb->termmeta} WHERE meta_key LIKE '_seo_forge_%'" );

		// Remove user meta
		$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE '_seo_forge_%'" );

		// Remove uploaded files
		$upload_dir = wp_upload_dir();
		$seo_forge_dir = $upload_dir['basedir'] . '/seo-forge';
		
		if ( file_exists( $seo_forge_dir ) ) {
			self::delete_directory( $seo_forge_dir );
		}
	}

	/**
	 * Delete directory recursively.
	 *
	 * @param string $dir Directory path.
	 */
	private static function delete_directory( $dir ) {
		if ( ! is_dir( $dir ) ) {
			return;
		}

		$files = array_diff( scandir( $dir ), [ '.', '..' ] );
		foreach ( $files as $file ) {
			$path = $dir . '/' . $file;
			if ( is_dir( $path ) ) {
				self::delete_directory( $path );
			} else {
				unlink( $path );
			}
		}
		rmdir( $dir );
	}
}