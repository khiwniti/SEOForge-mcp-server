<?php
/**
 * SEO Forge MCP Client Class
 *
 * @package SEO_FORGE
 */

namespace SEOForge;

defined( 'ABSPATH' ) || exit;

/**
 * MCP Client class for communicating with SEO Forge MCP server.
 */
class MCP_Client {

	/**
	 * API URL.
	 *
	 * @var string
	 */
	private $api_url;

	/**
	 * API Key.
	 *
	 * @var string
	 */
	private $api_key;

	/**
	 * Constructor.
	 */
	public function __construct() {
		$this->api_url = Helper::get_api_url();
		$this->api_key = Helper::get_api_key();

		add_action( 'wp_ajax_seo_forge_mcp_request', [ $this, 'handle_ajax_request' ] );
		add_action( 'wp_ajax_nopriv_seo_forge_mcp_request', [ $this, 'handle_ajax_request' ] );
	}

	/**
	 * Handle AJAX requests.
	 */
	public function handle_ajax_request() {
		check_ajax_referer( 'seo_forge_nonce', 'nonce' );

		$action = sanitize_text_field( $_POST['seo_forge_action'] ?? '' );
		$data = $_POST['data'] ?? [];

		if ( empty( $action ) ) {
			wp_send_json_error( __( 'Invalid action.', 'seo-forge' ) );
		}

		$response = $this->make_request( $action, $data );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( $response->get_error_message() );
		} else {
			wp_send_json_success( $response );
		}
	}

	/**
	 * Make API request to MCP server.
	 *
	 * @param string $action Action to perform.
	 * @param array  $data Request data.
	 * @return array|WP_Error
	 */
	public function make_request( $action, $data = [] ) {
		if ( empty( $this->api_url ) ) {
			return new \WP_Error( 'no_api_url', __( 'API URL not configured.', 'seo-forge' ) );
		}

		$url = trailingslashit( $this->api_url ) . 'wordpress/plugin';

		$headers = [
			'Content-Type' => 'application/json',
			'X-WordPress-Key' => $this->api_key,
			'X-WordPress-Site' => get_site_url(),
			'X-WordPress-Nonce' => $this->generate_nonce(),
			'X-WordPress-Timestamp' => time(),
			'User-Agent' => 'SEO Forge WordPress Plugin/' . SEO_FORGE_VERSION,
		];

		$body = wp_json_encode( [
			'action' => $action,
			'data' => $data,
			'site_url' => get_site_url(),
			'user_id' => get_current_user_id(),
			'language' => Helper::get_default_language(),
			'version' => SEO_FORGE_VERSION,
		] );

		$args = [
			'headers' => $headers,
			'body' => $body,
			'timeout' => 30,
			'method' => 'POST',
		];

		Helper::log( "Making MCP request to: $url with action: $action" );

		$response = wp_remote_post( $url, $args );

		if ( is_wp_error( $response ) ) {
			Helper::log( 'MCP request failed: ' . $response->get_error_message(), 'error' );
			return $response;
		}

		$response_code = wp_remote_retrieve_response_code( $response );
		$response_body = wp_remote_retrieve_body( $response );

		if ( $response_code !== 200 ) {
			Helper::log( "MCP request failed with code: $response_code", 'error' );
			return new \WP_Error( 'api_error', sprintf( __( 'API request failed with code: %d', 'seo-forge' ), $response_code ) );
		}

		$data = json_decode( $response_body, true );

		if ( json_last_error() !== JSON_ERROR_NONE ) {
			Helper::log( 'Invalid JSON response from MCP server', 'error' );
			return new \WP_Error( 'json_error', __( 'Invalid JSON response from server.', 'seo-forge' ) );
		}

		Helper::log( 'MCP request successful' );
		return $data;
	}

	/**
	 * Generate content using MCP server.
	 *
	 * @param array $params Generation parameters.
	 * @return array|WP_Error
	 */
	public function generate_content( $params ) {
		$default_params = [
			'type' => 'blog_post',
			'language' => Helper::get_default_language(),
			'tone' => 'professional',
			'length' => 'medium',
		];

		$params = wp_parse_args( $params, $default_params );

		return $this->make_request( 'generate_content', $params );
	}

	/**
	 * Analyze SEO using MCP server.
	 *
	 * @param array $params Analysis parameters.
	 * @return array|WP_Error
	 */
	public function analyze_seo( $params ) {
		$default_params = [
			'language' => Helper::get_default_language(),
			'check_readability' => true,
			'check_keywords' => true,
			'check_meta' => true,
		];

		$params = wp_parse_args( $params, $default_params );

		return $this->make_request( 'analyze_seo', $params );
	}

	/**
	 * Research keywords using MCP server.
	 *
	 * @param array $params Research parameters.
	 * @return array|WP_Error
	 */
	public function research_keywords( $params ) {
		$default_params = [
			'language' => Helper::get_default_language(),
			'country' => 'US',
			'limit' => 50,
		];

		$params = wp_parse_args( $params, $default_params );

		return $this->make_request( 'research_keywords', $params );
	}

	/**
	 * Generate image using MCP server.
	 *
	 * @param array $params Image generation parameters.
	 * @return array|WP_Error
	 */
	public function generate_image( $params ) {
		$default_params = [
			'style' => 'realistic',
			'size' => '1024x1024',
			'quality' => 'high',
		];

		$params = wp_parse_args( $params, $default_params );

		return $this->make_request( 'generate_image', $params );
	}

	/**
	 * Get content suggestions using MCP server.
	 *
	 * @param array $params Suggestion parameters.
	 * @return array|WP_Error
	 */
	public function get_suggestions( $params ) {
		$default_params = [
			'type' => 'improvement',
			'language' => Helper::get_default_language(),
		];

		$params = wp_parse_args( $params, $default_params );

		return $this->make_request( 'get_suggestions', $params );
	}

	/**
	 * Optimize content using MCP server.
	 *
	 * @param array $params Optimization parameters.
	 * @return array|WP_Error
	 */
	public function optimize_content( $params ) {
		$default_params = [
			'language' => Helper::get_default_language(),
			'focus_keyword' => '',
			'optimization_type' => 'seo',
		];

		$params = wp_parse_args( $params, $default_params );

		return $this->make_request( 'optimize_content', $params );
	}

	/**
	 * Get analytics data using MCP server.
	 *
	 * @param array $params Analytics parameters.
	 * @return array|WP_Error
	 */
	public function get_analytics( $params ) {
		$default_params = [
			'period' => '30d',
			'metrics' => [ 'impressions', 'clicks', 'ctr', 'position' ],
		];

		$params = wp_parse_args( $params, $default_params );

		return $this->make_request( 'get_analytics', $params );
	}

	/**
	 * Test API connection.
	 *
	 * @return array|WP_Error
	 */
	public function test_connection() {
		return $this->make_request( 'test_connection', [
			'timestamp' => time(),
			'site_info' => [
				'name' => get_bloginfo( 'name' ),
				'url' => get_site_url(),
				'admin_email' => get_option( 'admin_email' ),
				'wordpress_version' => get_bloginfo( 'version' ),
				'plugin_version' => SEO_FORGE_VERSION,
			],
		] );
	}

	/**
	 * Generate security nonce.
	 *
	 * @return string
	 */
	private function generate_nonce() {
		$site_url = get_site_url();
		$timestamp = time();
		$secret = $this->api_key ?: wp_salt();
		
		return hash( 'sha256', $site_url . ':' . $timestamp . ':' . $secret );
	}

	/**
	 * Get API status.
	 *
	 * @return array
	 */
	public function get_api_status() {
		$status = [
			'configured' => ! empty( $this->api_url ),
			'authenticated' => ! empty( $this->api_key ),
			'url' => $this->api_url,
			'last_check' => get_option( 'seo_forge_last_api_check', 0 ),
			'last_error' => get_option( 'seo_forge_last_api_error', '' ),
		];

		// Test connection if it's been more than an hour since last check
		if ( time() - $status['last_check'] > 3600 ) {
			$test_result = $this->test_connection();
			
			if ( is_wp_error( $test_result ) ) {
				$status['connected'] = false;
				$status['error'] = $test_result->get_error_message();
				update_option( 'seo_forge_last_api_error', $status['error'] );
			} else {
				$status['connected'] = true;
				$status['error'] = '';
				update_option( 'seo_forge_last_api_error', '' );
			}
			
			update_option( 'seo_forge_last_api_check', time() );
		} else {
			$status['connected'] = empty( $status['last_error'] );
			$status['error'] = get_option( 'seo_forge_last_api_error', '' );
		}

		return $status;
	}
}