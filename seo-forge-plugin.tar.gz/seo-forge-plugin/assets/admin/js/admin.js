/**
 * SEO Forge Admin JavaScript
 */

(function($) {
    'use strict';

    // Main SEO Forge Admin object
    window.SEOForgeAdmin = {
        
        // Initialize
        init: function() {
            this.bindEvents();
            this.initTabs();
            this.initTooltips();
            this.initProgressBars();
            this.checkApiStatus();
        },

        // Bind events
        bindEvents: function() {
            // Content generation
            $(document).on('click', '#generate-content-btn', this.generateContent);
            $(document).on('click', '#generate-suggestions-btn', this.generateSuggestions);
            
            // SEO analysis
            $(document).on('click', '#analyze-seo-btn', this.analyzeSEO);
            
            // Keyword research
            $(document).on('click', '#research-keywords-btn', this.researchKeywords);
            
            // Image generation
            $(document).on('click', '#generate-image-btn', this.generateImage);
            
            // Settings
            $(document).on('click', '#test-api-connection', this.testApiConnection);
            
            // Auto-save meta fields
            $(document).on('change', '.seo-forge-field input, .seo-forge-field textarea, .seo-forge-field select', this.autoSaveMeta);
        },

        // Initialize tabs
        initTabs: function() {
            $('.seo-forge-tabs a').on('click', function(e) {
                e.preventDefault();
                
                var $this = $(this);
                var target = $this.attr('href');
                
                // Update active tab
                $this.closest('.seo-forge-tabs').find('a').removeClass('active');
                $this.addClass('active');
                
                // Show target content
                $('.seo-forge-tab-content').removeClass('active');
                $(target).addClass('active');
            });
        },

        // Initialize tooltips
        initTooltips: function() {
            $('[data-tooltip]').each(function() {
                var $this = $(this);
                var tooltip = $this.data('tooltip');
                
                $this.attr('title', tooltip);
            });
        },

        // Initialize progress bars
        initProgressBars: function() {
            $('.seo-forge-progress-bar').each(function() {
                var $this = $(this);
                var percentage = $this.data('percentage') || 0;
                
                $this.css('width', percentage + '%');
                $this.find('.seo-forge-progress-text').text(percentage + '%');
            });
        },

        // Check API status
        checkApiStatus: function() {
            if (!seoForgeAdmin.apiUrl) {
                this.showNotice('warning', seoForgeAdmin.strings.error + ' API URL not configured.');
                return;
            }

            // Visual indicator that API is being checked
            $('.api-status-indicator').addClass('checking');
        },

        // Generate content
        generateContent: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var $container = $button.closest('.seo-forge-meta-section, .seo-forge-card');
            
            // Get form data
            var data = {
                keywords: $('#seoforge-keywords').val() || '',
                industry: $('#seoforge-industry').val() || '',
                content_type: $('#content-type').val() || 'blog_post',
                language: $('#content-language').val() || 'en',
                tone: $('#content-tone').val() || 'professional',
                length: $('#content-length').val() || 'medium'
            };

            if (!data.keywords) {
                SEOForgeAdmin.showNotice('error', 'Please enter keywords first.');
                return;
            }

            SEOForgeAdmin.makeRequest('generate_content', data, $button, function(response) {
                if (response.success && response.data) {
                    $('#generated-content').html(response.data.content || '');
                    $('#seoforge-content-result').show();
                    
                    // Auto-fill title and content if available
                    if (response.data.title && $('#title').length) {
                        $('#title').val(response.data.title);
                    }
                    
                    if (response.data.content && $('#content').length) {
                        if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
                            tinymce.get('content').setContent(response.data.content);
                        } else {
                            $('#content').val(response.data.content);
                        }
                    }
                    
                    SEOForgeAdmin.showNotice('success', 'Content generated successfully!');
                } else {
                    SEOForgeAdmin.showNotice('error', response.data || 'Failed to generate content.');
                }
            });
        },

        // Generate suggestions
        generateSuggestions: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var data = {
                content: SEOForgeAdmin.getCurrentContent(),
                keywords: $('#seoforge-keywords').val() || '',
                type: 'improvement'
            };

            SEOForgeAdmin.makeRequest('get_suggestions', data, $button, function(response) {
                if (response.success && response.data) {
                    SEOForgeAdmin.displaySuggestions(response.data.suggestions || []);
                    SEOForgeAdmin.showNotice('success', 'Suggestions generated successfully!');
                } else {
                    SEOForgeAdmin.showNotice('error', response.data || 'Failed to generate suggestions.');
                }
            });
        },

        // Analyze SEO
        analyzeSEO: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var data = {
                title: $('#title').val() || '',
                content: SEOForgeAdmin.getCurrentContent(),
                meta_description: $('#meta_description').val() || '',
                focus_keyword: $('#focus_keyword').val() || '',
                url: window.location.href
            };

            SEOForgeAdmin.makeRequest('analyze_seo', data, $button, function(response) {
                if (response.success && response.data) {
                    SEOForgeAdmin.displaySEOAnalysis(response.data);
                    $('#seoforge-seo-result').show();
                    SEOForgeAdmin.showNotice('success', 'SEO analysis completed!');
                } else {
                    SEOForgeAdmin.showNotice('error', response.data || 'Failed to analyze SEO.');
                }
            });
        },

        // Research keywords
        researchKeywords: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var data = {
                seed_keywords: $('#seed-keywords').val() || '',
                language: $('#keyword-language').val() || 'en',
                country: $('#keyword-country').val() || 'US',
                limit: $('#keyword-limit').val() || 50
            };

            if (!data.seed_keywords) {
                SEOForgeAdmin.showNotice('error', 'Please enter seed keywords first.');
                return;
            }

            SEOForgeAdmin.makeRequest('research_keywords', data, $button, function(response) {
                if (response.success && response.data) {
                    SEOForgeAdmin.displayKeywordResults(response.data.keywords || []);
                    SEOForgeAdmin.showNotice('success', 'Keyword research completed!');
                } else {
                    SEOForgeAdmin.showNotice('error', response.data || 'Failed to research keywords.');
                }
            });
        },

        // Generate image
        generateImage: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var data = {
                prompt: $('#image-prompt').val() || '',
                style: $('#image-style').val() || 'realistic',
                size: $('#image-size').val() || '1024x1024'
            };

            if (!data.prompt) {
                SEOForgeAdmin.showNotice('error', 'Please enter an image prompt first.');
                return;
            }

            SEOForgeAdmin.makeRequest('generate_image', data, $button, function(response) {
                if (response.success && response.data) {
                    SEOForgeAdmin.displayGeneratedImage(response.data);
                    SEOForgeAdmin.showNotice('success', 'Image generated successfully!');
                } else {
                    SEOForgeAdmin.showNotice('error', response.data || 'Failed to generate image.');
                }
            });
        },

        // Test API connection
        testApiConnection: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            
            SEOForgeAdmin.makeRequest('test_connection', {}, $button, function(response) {
                if (response.success) {
                    SEOForgeAdmin.showNotice('success', 'API connection successful!');
                    $('.api-status-indicator').removeClass('error').addClass('success');
                } else {
                    SEOForgeAdmin.showNotice('error', 'API connection failed: ' + (response.data || 'Unknown error'));
                    $('.api-status-indicator').removeClass('success').addClass('error');
                }
            });
        },

        // Auto-save meta fields
        autoSaveMeta: function() {
            var $field = $(this);
            var fieldName = $field.attr('name');
            var fieldValue = $field.val();
            var postId = $('#post_ID').val();

            if (!postId || !fieldName) return;

            // Debounce auto-save
            clearTimeout(SEOForgeAdmin.autoSaveTimeout);
            SEOForgeAdmin.autoSaveTimeout = setTimeout(function() {
                $.post(ajaxurl, {
                    action: 'seo_forge_auto_save_meta',
                    nonce: seoForgeAdmin.nonce,
                    post_id: postId,
                    field_name: fieldName,
                    field_value: fieldValue
                });
            }, 1000);
        },

        // Make AJAX request to MCP server
        makeRequest: function(action, data, $button, callback) {
            var originalText = $button.text();
            var loadingText = seoForgeAdmin.strings.loading;

            // Update button state
            $button.prop('disabled', true).text(loadingText).addClass('seo-forge-loading');

            $.post(seoForgeAdmin.ajaxUrl, {
                action: 'seo_forge_mcp_request',
                nonce: seoForgeAdmin.nonce,
                seo_forge_action: action,
                data: data
            })
            .done(function(response) {
                callback(response);
            })
            .fail(function() {
                SEOForgeAdmin.showNotice('error', seoForgeAdmin.strings.error);
            })
            .always(function() {
                // Restore button state
                $button.prop('disabled', false).text(originalText).removeClass('seo-forge-loading');
            });
        },

        // Get current content from editor
        getCurrentContent: function() {
            if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
                return tinymce.get('content').getContent();
            } else if ($('#content').length) {
                return $('#content').val();
            }
            return '';
        },

        // Display suggestions
        displaySuggestions: function(suggestions) {
            var html = '<ul class="seo-forge-suggestions">';
            
            suggestions.forEach(function(suggestion) {
                html += '<li class="suggestion-' + (suggestion.priority || 'medium') + '">';
                html += '<strong>' + (suggestion.title || 'Suggestion') + '</strong>: ';
                html += suggestion.text || suggestion.suggestion || '';
                html += '</li>';
            });
            
            html += '</ul>';
            
            $('#suggestions-content').html(html);
            $('#seoforge-suggestions-result').show();
        },

        // Display SEO analysis
        displaySEOAnalysis: function(analysis) {
            var score = analysis.score || 0;
            var scoreClass = 'poor';
            
            if (score >= 80) scoreClass = 'excellent';
            else if (score >= 60) scoreClass = 'good';
            else if (score >= 40) scoreClass = 'fair';

            var html = '<div class="seo-analysis-result">';
            html += '<div class="seo-score-container">';
            html += '<div class="seo-forge-score ' + scoreClass + '">' + score + '</div>';
            html += '<div class="score-details">';
            html += '<h4>SEO Score: ' + score + '/100</h4>';
            html += '<p>' + (analysis.summary || 'Analysis completed') + '</p>';
            html += '</div>';
            html += '</div>';

            if (analysis.issues && analysis.issues.length > 0) {
                html += '<div class="seo-issues">';
                html += '<h5>Issues Found:</h5>';
                html += '<ul>';
                analysis.issues.forEach(function(issue) {
                    html += '<li class="issue-' + (issue.severity || 'medium') + '">' + issue.message + '</li>';
                });
                html += '</ul>';
                html += '</div>';
            }

            if (analysis.recommendations && analysis.recommendations.length > 0) {
                html += '<div class="seo-recommendations">';
                html += '<h5>Recommendations:</h5>';
                html += '<ul>';
                analysis.recommendations.forEach(function(rec) {
                    html += '<li>' + rec.message + '</li>';
                });
                html += '</ul>';
                html += '</div>';
            }

            html += '</div>';

            $('#seo-analysis-content').html(html);
        },

        // Display keyword results
        displayKeywordResults: function(keywords) {
            var html = '<div class="keyword-results">';
            html += '<table class="wp-list-table widefat fixed striped">';
            html += '<thead><tr>';
            html += '<th>Keyword</th>';
            html += '<th>Search Volume</th>';
            html += '<th>Difficulty</th>';
            html += '<th>CPC</th>';
            html += '<th>Actions</th>';
            html += '</tr></thead>';
            html += '<tbody>';

            keywords.forEach(function(keyword) {
                html += '<tr>';
                html += '<td><strong>' + keyword.keyword + '</strong></td>';
                html += '<td>' + (keyword.search_volume || 'N/A') + '</td>';
                html += '<td>' + (keyword.difficulty || 'N/A') + '</td>';
                html += '<td>$' + (keyword.cpc || '0.00') + '</td>';
                html += '<td><button class="button button-small use-keyword" data-keyword="' + keyword.keyword + '">Use</button></td>';
                html += '</tr>';
            });

            html += '</tbody></table>';
            html += '</div>';

            $('#keyword-results').html(html);

            // Bind use keyword buttons
            $('.use-keyword').on('click', function() {
                var keyword = $(this).data('keyword');
                $('#seoforge-keywords').val(keyword);
                $('#focus_keyword').val(keyword);
                SEOForgeAdmin.showNotice('success', 'Keyword "' + keyword + '" added to focus keyword.');
            });
        },

        // Display generated image
        displayGeneratedImage: function(imageData) {
            var html = '<div class="generated-image-result">';
            html += '<img src="' + imageData.url + '" alt="Generated Image" style="max-width: 100%; height: auto;" />';
            html += '<div class="image-actions" style="margin-top: 10px;">';
            html += '<button class="button button-primary use-as-featured" data-url="' + imageData.url + '">Use as Featured Image</button>';
            html += '<button class="button download-image" data-url="' + imageData.url + '">Download</button>';
            html += '</div>';
            html += '</div>';

            $('#generated-image-content').html(html);

            // Bind image action buttons
            $('.use-as-featured').on('click', function() {
                var imageUrl = $(this).data('url');
                // Implementation for setting as featured image would go here
                SEOForgeAdmin.showNotice('info', 'Feature to set as featured image coming soon!');
            });

            $('.download-image').on('click', function() {
                var imageUrl = $(this).data('url');
                window.open(imageUrl, '_blank');
            });
        },

        // Show notice
        showNotice: function(type, message) {
            var $notice = $('<div class="seo-forge-alert ' + type + '">' + message + '</div>');
            
            // Remove existing notices
            $('.seo-forge-alert').remove();
            
            // Add new notice
            if ($('.seo-forge-container').length) {
                $('.seo-forge-container').prepend($notice);
            } else {
                $('.wrap').prepend($notice);
            }

            // Auto-hide after 5 seconds
            setTimeout(function() {
                $notice.fadeOut(function() {
                    $notice.remove();
                });
            }, 5000);
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        SEOForgeAdmin.init();
    });

})(jQuery);