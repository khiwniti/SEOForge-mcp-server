/**
 * SEO Forge Frontend JavaScript
 */

(function($) {
    'use strict';

    // SEO Forge Frontend object
    window.SEOForgeFrontend = {
        
        // Initialize
        init: function() {
            this.bindEvents();
            this.initWidgets();
        },

        // Bind events
        bindEvents: function() {
            // Add any frontend event handlers here
        },

        // Initialize widgets
        initWidgets: function() {
            // Initialize any frontend widgets
            $('.seo-forge-widget').each(function() {
                // Widget initialization code
            });
        }
    };

    // Initialize when document is ready
    $(document).ready(function() {
        SEOForgeFrontend.init();
    });

})(jQuery);