<?php
/**
 * SEO Meta Box Template
 *
 * @package SEO_FORGE
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="seo-forge-meta-box">
	<div class="seo-forge-meta-section">
		<h4><?php esc_html_e( 'SEO Title & Description', 'seo-forge' ); ?></h4>
		
		<div class="seo-forge-field">
			<label for="title"><?php esc_html_e( 'SEO Title', 'seo-forge' ); ?></label>
			<input type="text" id="title" name="title" value="<?php echo esc_attr( $title ); ?>" class="large-text" maxlength="60" />
			<p class="description">
				<?php esc_html_e( 'The title that appears in search engine results. Keep it under 60 characters.', 'seo-forge' ); ?>
				<span class="char-count">0/60</span>
			</p>
		</div>

		<div class="seo-forge-field">
			<label for="meta_description"><?php esc_html_e( 'Meta Description', 'seo-forge' ); ?></label>
			<textarea id="meta_description" name="meta_description" rows="3" class="large-text" maxlength="160"><?php echo esc_textarea( $description ); ?></textarea>
			<p class="description">
				<?php esc_html_e( 'A brief description that appears in search results. Keep it under 160 characters.', 'seo-forge' ); ?>
				<span class="char-count">0/160</span>
			</p>
		</div>

		<div class="seo-forge-field">
			<label for="meta_keywords"><?php esc_html_e( 'Meta Keywords', 'seo-forge' ); ?></label>
			<input type="text" id="meta_keywords" name="meta_keywords" value="<?php echo esc_attr( $keywords ); ?>" class="large-text" />
			<p class="description"><?php esc_html_e( 'Keywords separated by commas. Used for internal tracking and some search engines.', 'seo-forge' ); ?></p>
		</div>

		<div class="seo-forge-field">
			<label for="focus_keyword"><?php esc_html_e( 'Focus Keyword', 'seo-forge' ); ?></label>
			<input type="text" id="focus_keyword" name="focus_keyword" value="<?php echo esc_attr( $focus_keyword ); ?>" class="large-text" />
			<p class="description"><?php esc_html_e( 'The main keyword you want this content to rank for.', 'seo-forge' ); ?></p>
		</div>
	</div>

	<div class="seo-forge-meta-section">
		<h4><?php esc_html_e( 'Search Preview', 'seo-forge' ); ?></h4>
		<div id="search-preview" class="search-preview">
			<div class="preview-title"><?php echo esc_html( $title ?: get_the_title( $post ) ); ?></div>
			<div class="preview-url"><?php echo esc_url( get_permalink( $post ) ); ?></div>
			<div class="preview-description"><?php echo esc_html( $description ?: wp_trim_words( strip_tags( $post->post_content ), 25 ) ); ?></div>
		</div>
	</div>

	<div class="seo-forge-meta-section">
		<h4><?php esc_html_e( 'SEO Analysis', 'seo-forge' ); ?></h4>
		<div id="seo-analysis-summary">
			<p><?php esc_html_e( 'Click "Analyze SEO" in the sidebar to get detailed analysis and recommendations.', 'seo-forge' ); ?></p>
		</div>
	</div>
</div>

<style>
.search-preview {
	border: 1px solid #ddd;
	padding: 15px;
	background: #f9f9f9;
	border-radius: 4px;
	font-family: arial, sans-serif;
}

.preview-title {
	color: #1a0dab;
	font-size: 18px;
	line-height: 1.2;
	margin-bottom: 2px;
	cursor: pointer;
}

.preview-url {
	color: #006621;
	font-size: 14px;
	margin-bottom: 2px;
}

.preview-description {
	color: #545454;
	font-size: 13px;
	line-height: 1.4;
}

.char-count {
	float: right;
	font-size: 12px;
	color: #666;
}

.char-count.over-limit {
	color: #d63638;
	font-weight: bold;
}
</style>

<script>
jQuery(document).ready(function($) {
	// Character counting
	function updateCharCount(input, limit) {
		var $input = $(input);
		var $counter = $input.siblings('.description').find('.char-count');
		var length = $input.val().length;
		
		$counter.text(length + '/' + limit);
		
		if (length > limit) {
			$counter.addClass('over-limit');
		} else {
			$counter.removeClass('over-limit');
		}
	}

	// Update character counts on input
	$('#title').on('input', function() {
		updateCharCount(this, 60);
		updateSearchPreview();
	});

	$('#meta_description').on('input', function() {
		updateCharCount(this, 160);
		updateSearchPreview();
	});

	// Update search preview
	function updateSearchPreview() {
		var title = $('#title').val() || $('input[name="post_title"]').val() || 'Your Page Title';
		var description = $('#meta_description').val() || 'Your meta description will appear here...';
		
		$('.preview-title').text(title);
		$('.preview-description').text(description);
	}

	// Initialize character counts
	updateCharCount('#title', 60);
	updateCharCount('#meta_description', 160);
	updateSearchPreview();
});
</script>