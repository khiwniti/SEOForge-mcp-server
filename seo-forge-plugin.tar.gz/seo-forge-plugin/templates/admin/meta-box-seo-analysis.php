<?php
/**
 * SEO Analysis Meta Box Template
 *
 * @package SEO_FORGE
 */

defined( 'ABSPATH' ) || exit;
?>

<div class="seo-forge-meta-box">
	<div class="seo-forge-meta-section">
		<h4><?php esc_html_e( 'SEO Analysis', 'seo-forge' ); ?></h4>
		
		<?php if ( $last_analysis ) : ?>
			<div class="last-analysis-info">
				<p><strong><?php esc_html_e( 'Last Analysis:', 'seo-forge' ); ?></strong> <?php echo esc_html( date_i18n( get_option( 'date_format' ) . ' ' . get_option( 'time_format' ), strtotime( $last_analysis ) ) ); ?></p>
				<?php if ( $seo_score ) : ?>
					<div class="current-score">
						<span class="seo-forge-score <?php echo $seo_score >= 80 ? 'excellent' : ( $seo_score >= 60 ? 'good' : ( $seo_score >= 40 ? 'fair' : 'poor' ) ); ?>">
							<?php echo esc_html( $seo_score ); ?>
						</span>
						<span class="score-label"><?php esc_html_e( 'SEO Score', 'seo-forge' ); ?></span>
					</div>
				<?php endif; ?>
			</div>
		<?php else : ?>
			<p class="no-analysis"><?php esc_html_e( 'No SEO analysis performed yet.', 'seo-forge' ); ?></p>
		<?php endif; ?>

		<div class="seo-forge-field">
			<button type="button" id="analyze-seo-btn" class="seo-forge-button">
				<?php esc_html_e( 'Analyze SEO', 'seo-forge' ); ?>
			</button>
			<button type="button" id="quick-check-btn" class="seo-forge-button secondary">
				<?php esc_html_e( 'Quick Check', 'seo-forge' ); ?>
			</button>
		</div>

		<div id="seoforge-seo-result" style="display:none;">
			<h4><?php esc_html_e( 'Analysis Results', 'seo-forge' ); ?></h4>
			<div id="seo-analysis-content"></div>
		</div>
	</div>

	<div class="seo-forge-meta-section">
		<h4><?php esc_html_e( 'Quick SEO Checklist', 'seo-forge' ); ?></h4>
		<div id="seo-checklist">
			<div class="checklist-item" data-check="title">
				<span class="check-icon">⏳</span>
				<span class="check-text"><?php esc_html_e( 'SEO Title (recommended: 50-60 characters)', 'seo-forge' ); ?></span>
			</div>
			<div class="checklist-item" data-check="description">
				<span class="check-icon">⏳</span>
				<span class="check-text"><?php esc_html_e( 'Meta Description (recommended: 150-160 characters)', 'seo-forge' ); ?></span>
			</div>
			<div class="checklist-item" data-check="keyword">
				<span class="check-icon">⏳</span>
				<span class="check-text"><?php esc_html_e( 'Focus Keyword Set', 'seo-forge' ); ?></span>
			</div>
			<div class="checklist-item" data-check="content">
				<span class="check-icon">⏳</span>
				<span class="check-text"><?php esc_html_e( 'Content Length (recommended: 300+ words)', 'seo-forge' ); ?></span>
			</div>
			<div class="checklist-item" data-check="headings">
				<span class="check-icon">⏳</span>
				<span class="check-text"><?php esc_html_e( 'Proper Heading Structure (H1, H2, H3)', 'seo-forge' ); ?></span>
			</div>
			<div class="checklist-item" data-check="images">
				<span class="check-icon">⏳</span>
				<span class="check-text"><?php esc_html_e( 'Images with Alt Text', 'seo-forge' ); ?></span>
			</div>
		</div>
	</div>

	<div class="seo-forge-meta-section">
		<h4><?php esc_html_e( 'Content Optimization', 'seo-forge' ); ?></h4>
		
		<div class="seo-forge-field">
			<button type="button" id="optimize-content-btn" class="seo-forge-button">
				<?php esc_html_e( 'Optimize Content', 'seo-forge' ); ?>
			</button>
			<button type="button" id="readability-check-btn" class="seo-forge-button secondary">
				<?php esc_html_e( 'Check Readability', 'seo-forge' ); ?>
			</button>
		</div>

		<div id="optimization-suggestions" style="display:none;">
			<h4><?php esc_html_e( 'Optimization Suggestions', 'seo-forge' ); ?></h4>
			<div id="optimization-content"></div>
		</div>
	</div>
</div>

<style>
.last-analysis-info {
	background: #f0f8ff;
	border: 1px solid #e0e8f0;
	padding: 15px;
	border-radius: 4px;
	margin-bottom: 15px;
}

.current-score {
	display: flex;
	align-items: center;
	gap: 10px;
	margin-top: 10px;
}

.score-label {
	font-weight: 600;
	color: #374151;
}

.no-analysis {
	color: #6b7280;
	font-style: italic;
}

.seo-checklist {
	list-style: none;
	padding: 0;
	margin: 0;
}

.checklist-item {
	display: flex;
	align-items: center;
	gap: 10px;
	padding: 8px 0;
	border-bottom: 1px solid #f0f0f0;
}

.checklist-item:last-child {
	border-bottom: none;
}

.check-icon {
	font-size: 16px;
	width: 20px;
	text-align: center;
}

.checklist-item.pass .check-icon {
	color: #10b981;
}

.checklist-item.fail .check-icon {
	color: #ef4444;
}

.checklist-item.warning .check-icon {
	color: #f59e0b;
}

.check-text {
	flex: 1;
	font-size: 13px;
}

.seo-analysis-result {
	background: #f9f9f9;
	border: 1px solid #ddd;
	padding: 15px;
	border-radius: 4px;
	margin: 10px 0;
}

.seo-score-container {
	display: flex;
	align-items: center;
	gap: 15px;
	margin-bottom: 20px;
}

.score-details h4 {
	margin: 0 0 5px;
	color: #374151;
}

.score-details p {
	margin: 0;
	color: #6b7280;
	font-size: 14px;
}

.seo-issues,
.seo-recommendations {
	margin-top: 20px;
}

.seo-issues h5,
.seo-recommendations h5 {
	margin: 0 0 10px;
	color: #374151;
	font-size: 14px;
	font-weight: 600;
}

.seo-issues ul,
.seo-recommendations ul {
	list-style: none;
	padding: 0;
	margin: 0;
}

.seo-issues li,
.seo-recommendations li {
	padding: 8px 12px;
	margin-bottom: 5px;
	border-radius: 4px;
	font-size: 13px;
	line-height: 1.4;
}

.seo-issues li {
	background: #fef2f2;
	border-left: 3px solid #ef4444;
}

.seo-issues li.issue-high {
	background: #fef2f2;
	border-left-color: #dc2626;
}

.seo-issues li.issue-medium {
	background: #fffbeb;
	border-left-color: #f59e0b;
}

.seo-issues li.issue-low {
	background: #f0fdf4;
	border-left-color: #10b981;
}

.seo-recommendations li {
	background: #eff6ff;
	border-left: 3px solid #2563eb;
}
</style>

<script>
jQuery(document).ready(function($) {
	// Quick SEO check
	function performQuickCheck() {
		var checks = {
			title: {
				element: '#title',
				min: 30,
				max: 60,
				test: function(val) {
					return val.length >= this.min && val.length <= this.max;
				}
			},
			description: {
				element: '#meta_description',
				min: 120,
				max: 160,
				test: function(val) {
					return val.length >= this.min && val.length <= this.max;
				}
			},
			keyword: {
				element: '#focus_keyword',
				test: function(val) {
					return val.length > 0;
				}
			},
			content: {
				element: '#content',
				min: 300,
				test: function(val) {
					var text = val.replace(/<[^>]*>/g, '').trim();
					var words = text.split(/\s+/).length;
					return words >= this.min;
				}
			},
			headings: {
				element: '#content',
				test: function(val) {
					return /<h[1-6][^>]*>/i.test(val);
				}
			},
			images: {
				element: '#content',
				test: function(val) {
					var images = val.match(/<img[^>]*>/gi) || [];
					if (images.length === 0) return true; // No images is okay
					
					var withAlt = images.filter(function(img) {
						return /alt\s*=\s*["'][^"']*["']/i.test(img);
					});
					
					return withAlt.length === images.length;
				}
			}
		};

		Object.keys(checks).forEach(function(checkName) {
			var check = checks[checkName];
			var $element = $(check.element);
			var value = $element.val() || '';
			
			if (typeof tinymce !== 'undefined' && checkName === 'content' && tinymce.get('content')) {
				value = tinymce.get('content').getContent();
			}

			var $item = $('.checklist-item[data-check="' + checkName + '"]');
			var $icon = $item.find('.check-icon');
			
			var passed = check.test(value);
			
			$item.removeClass('pass fail warning');
			
			if (passed) {
				$item.addClass('pass');
				$icon.text('✅');
			} else if (checkName === 'title' || checkName === 'description') {
				var length = value.length;
				if (length === 0) {
					$item.addClass('fail');
					$icon.text('❌');
				} else if (length < check.min || length > check.max) {
					$item.addClass('warning');
					$icon.text('⚠️');
				}
			} else {
				$item.addClass('fail');
				$icon.text('❌');
			}
		});
	}

	// Quick check button
	$('#quick-check-btn').on('click', function() {
		performQuickCheck();
		SEOForgeAdmin.showNotice('info', '<?php esc_html_e( 'Quick SEO check completed!', 'seo-forge' ); ?>');
	});

	// Optimize content
	$('#optimize-content-btn').on('click', function() {
		var $button = $(this);
		var data = {
			title: $('#title').val() || '',
			content: SEOForgeAdmin.getCurrentContent(),
			focus_keyword: $('#focus_keyword').val() || '',
			optimization_type: 'seo'
		};

		SEOForgeAdmin.makeRequest('optimize_content', data, $button, function(response) {
			if (response.success && response.data) {
				displayOptimizationSuggestions(response.data.suggestions || []);
				$('#optimization-suggestions').show();
				SEOForgeAdmin.showNotice('success', '<?php esc_html_e( 'Content optimization completed!', 'seo-forge' ); ?>');
			} else {
				SEOForgeAdmin.showNotice('error', response.data || '<?php esc_html_e( 'Failed to optimize content.', 'seo-forge' ); ?>');
			}
		});
	});

	// Readability check
	$('#readability-check-btn').on('click', function() {
		var $button = $(this);
		var data = {
			content: SEOForgeAdmin.getCurrentContent(),
			check_type: 'readability'
		};

		SEOForgeAdmin.makeRequest('analyze_seo', data, $button, function(response) {
			if (response.success && response.data) {
				displayReadabilityResults(response.data);
				SEOForgeAdmin.showNotice('success', '<?php esc_html_e( 'Readability check completed!', 'seo-forge' ); ?>');
			} else {
				SEOForgeAdmin.showNotice('error', response.data || '<?php esc_html_e( 'Failed to check readability.', 'seo-forge' ); ?>');
			}
		});
	});

	// Display optimization suggestions
	function displayOptimizationSuggestions(suggestions) {
		var html = '<ul class="optimization-suggestions">';
		
		suggestions.forEach(function(suggestion) {
			html += '<li class="suggestion-' + (suggestion.priority || 'medium') + '">';
			html += '<strong>' + (suggestion.title || '<?php esc_html_e( 'Suggestion', 'seo-forge' ); ?>') + '</strong>: ';
			html += suggestion.text || suggestion.suggestion || '';
			html += '</li>';
		});
		
		html += '</ul>';
		
		$('#optimization-content').html(html);
	}

	// Display readability results
	function displayReadabilityResults(results) {
		var html = '<div class="readability-results">';
		html += '<div class="readability-score">';
		html += '<span class="score">' + (results.readability_score || 'N/A') + '</span>';
		html += '<span class="score-label"><?php esc_html_e( 'Readability Score', 'seo-forge' ); ?></span>';
		html += '</div>';
		
		if (results.readability_issues && results.readability_issues.length > 0) {
			html += '<div class="readability-issues">';
			html += '<h5><?php esc_html_e( 'Readability Issues:', 'seo-forge' ); ?></h5>';
			html += '<ul>';
			results.readability_issues.forEach(function(issue) {
				html += '<li>' + issue.message + '</li>';
			});
			html += '</ul>';
			html += '</div>';
		}
		
		html += '</div>';
		
		$('#optimization-content').html(html);
		$('#optimization-suggestions').show();
	}

	// Auto-run quick check when fields change
	$('#title, #meta_description, #focus_keyword').on('input', function() {
		clearTimeout(window.quickCheckTimeout);
		window.quickCheckTimeout = setTimeout(performQuickCheck, 1000);
	});

	// Initial quick check
	performQuickCheck();
});
</script>