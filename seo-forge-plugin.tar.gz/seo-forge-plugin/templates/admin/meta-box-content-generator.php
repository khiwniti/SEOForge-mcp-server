<?php
/**
 * Content Generator Meta Box Template
 *
 * @package SEO_FORGE
 */

defined( 'ABSPATH' ) || exit;

use SEOForge\Helper;
?>

<div class="seo-forge-meta-box">
	<div class="seo-forge-meta-section">
		<h4><?php esc_html_e( 'Content Generation', 'seo-forge' ); ?></h4>
		
		<div class="seo-forge-field">
			<label for="seoforge-keywords"><?php esc_html_e( 'Keywords', 'seo-forge' ); ?></label>
			<input type="text" id="seoforge-keywords" name="keywords" value="<?php echo esc_attr( $keywords ); ?>" class="large-text" placeholder="<?php esc_attr_e( 'Enter keywords separated by commas', 'seo-forge' ); ?>" />
			<p class="description"><?php esc_html_e( 'Keywords to focus on for content generation', 'seo-forge' ); ?></p>
		</div>

		<div class="seo-forge-field">
			<label for="seoforge-industry"><?php esc_html_e( 'Industry', 'seo-forge' ); ?></label>
			<select id="seoforge-industry" name="industry">
				<option value=""><?php esc_html_e( 'Select Industry', 'seo-forge' ); ?></option>
				<?php foreach ( Helper::get_industries() as $value => $label ) : ?>
					<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $industry, $value ); ?>>
						<?php echo esc_html( $label ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<p class="description"><?php esc_html_e( 'Industry context for better content generation', 'seo-forge' ); ?></p>
		</div>

		<div class="seo-forge-field">
			<label for="content-type"><?php esc_html_e( 'Content Type', 'seo-forge' ); ?></label>
			<select id="content-type">
				<option value="blog_post"><?php esc_html_e( 'Blog Post', 'seo-forge' ); ?></option>
				<option value="product_description"><?php esc_html_e( 'Product Description', 'seo-forge' ); ?></option>
				<option value="landing_page"><?php esc_html_e( 'Landing Page', 'seo-forge' ); ?></option>
				<option value="news_article"><?php esc_html_e( 'News Article', 'seo-forge' ); ?></option>
				<option value="how_to_guide"><?php esc_html_e( 'How-to Guide', 'seo-forge' ); ?></option>
			</select>
		</div>

		<div class="seo-forge-field">
			<label for="content-tone"><?php esc_html_e( 'Tone', 'seo-forge' ); ?></label>
			<select id="content-tone">
				<option value="professional"><?php esc_html_e( 'Professional', 'seo-forge' ); ?></option>
				<option value="casual"><?php esc_html_e( 'Casual', 'seo-forge' ); ?></option>
				<option value="friendly"><?php esc_html_e( 'Friendly', 'seo-forge' ); ?></option>
				<option value="authoritative"><?php esc_html_e( 'Authoritative', 'seo-forge' ); ?></option>
				<option value="conversational"><?php esc_html_e( 'Conversational', 'seo-forge' ); ?></option>
			</select>
		</div>

		<div class="seo-forge-field">
			<label for="content-length"><?php esc_html_e( 'Length', 'seo-forge' ); ?></label>
			<select id="content-length">
				<option value="short"><?php esc_html_e( 'Short (300-500 words)', 'seo-forge' ); ?></option>
				<option value="medium" selected><?php esc_html_e( 'Medium (500-1000 words)', 'seo-forge' ); ?></option>
				<option value="long"><?php esc_html_e( 'Long (1000+ words)', 'seo-forge' ); ?></option>
			</select>
		</div>

		<div class="seo-forge-field">
			<label for="content-language"><?php esc_html_e( 'Language', 'seo-forge' ); ?></label>
			<select id="content-language">
				<?php foreach ( Helper::get_supported_languages() as $code => $name ) : ?>
					<option value="<?php echo esc_attr( $code ); ?>" <?php selected( Helper::get_default_language(), $code ); ?>>
						<?php echo esc_html( $name ); ?>
					</option>
				<?php endforeach; ?>
			</select>
		</div>

		<div class="seo-forge-field">
			<button type="button" id="generate-content-btn" class="seo-forge-button">
				<?php esc_html_e( 'Generate Content', 'seo-forge' ); ?>
			</button>
			<button type="button" id="generate-suggestions-btn" class="seo-forge-button secondary">
				<?php esc_html_e( 'Get Suggestions', 'seo-forge' ); ?>
			</button>
		</div>

		<div id="seoforge-content-result" style="display:none;">
			<h4><?php esc_html_e( 'Generated Content', 'seo-forge' ); ?></h4>
			<div id="generated-content" class="generated-content"></div>
			<div class="content-actions">
				<button type="button" id="use-content-btn" class="seo-forge-button success">
					<?php esc_html_e( 'Use This Content', 'seo-forge' ); ?>
				</button>
				<button type="button" id="regenerate-content-btn" class="seo-forge-button secondary">
					<?php esc_html_e( 'Regenerate', 'seo-forge' ); ?>
				</button>
			</div>
		</div>

		<div id="seoforge-suggestions-result" style="display:none;">
			<h4><?php esc_html_e( 'Content Suggestions', 'seo-forge' ); ?></h4>
			<div id="suggestions-content"></div>
		</div>
	</div>

	<div class="seo-forge-meta-section">
		<h4><?php esc_html_e( 'Image Generation', 'seo-forge' ); ?></h4>
		
		<div class="seo-forge-field">
			<label for="image-prompt"><?php esc_html_e( 'Image Description', 'seo-forge' ); ?></label>
			<textarea id="image-prompt" rows="3" class="large-text" placeholder="<?php esc_attr_e( 'Describe the image you want to generate...', 'seo-forge' ); ?>"></textarea>
			<p class="description"><?php esc_html_e( 'Describe the image you want to generate for this content', 'seo-forge' ); ?></p>
		</div>

		<div class="seo-forge-field">
			<label for="image-style"><?php esc_html_e( 'Style', 'seo-forge' ); ?></label>
			<select id="image-style">
				<option value="realistic"><?php esc_html_e( 'Realistic', 'seo-forge' ); ?></option>
				<option value="illustration"><?php esc_html_e( 'Illustration', 'seo-forge' ); ?></option>
				<option value="cartoon"><?php esc_html_e( 'Cartoon', 'seo-forge' ); ?></option>
				<option value="abstract"><?php esc_html_e( 'Abstract', 'seo-forge' ); ?></option>
				<option value="minimalist"><?php esc_html_e( 'Minimalist', 'seo-forge' ); ?></option>
			</select>
		</div>

		<div class="seo-forge-field">
			<label for="image-size"><?php esc_html_e( 'Size', 'seo-forge' ); ?></label>
			<select id="image-size">
				<option value="1024x1024"><?php esc_html_e( 'Square (1024x1024)', 'seo-forge' ); ?></option>
				<option value="1792x1024"><?php esc_html_e( 'Landscape (1792x1024)', 'seo-forge' ); ?></option>
				<option value="1024x1792"><?php esc_html_e( 'Portrait (1024x1792)', 'seo-forge' ); ?></option>
			</select>
		</div>

		<div class="seo-forge-field">
			<button type="button" id="generate-image-btn" class="seo-forge-button">
				<?php esc_html_e( 'Generate Image', 'seo-forge' ); ?>
			</button>
		</div>

		<div id="generated-image-result" style="display:none;">
			<h4><?php esc_html_e( 'Generated Image', 'seo-forge' ); ?></h4>
			<div id="generated-image-content"></div>
		</div>
	</div>
</div>

<style>
.generated-content {
	background: #f9f9f9;
	border: 1px solid #ddd;
	padding: 15px;
	border-radius: 4px;
	margin: 10px 0;
	max-height: 300px;
	overflow-y: auto;
}

.content-actions {
	margin-top: 10px;
	display: flex;
	gap: 10px;
}

.seo-forge-suggestions ul {
	list-style: none;
	padding: 0;
}

.seo-forge-suggestions li {
	background: #f0f8ff;
	border-left: 4px solid #2563eb;
	padding: 10px 15px;
	margin-bottom: 10px;
	border-radius: 0 4px 4px 0;
}

.seo-forge-suggestions li.suggestion-high {
	border-left-color: #ef4444;
	background: #fef2f2;
}

.seo-forge-suggestions li.suggestion-medium {
	border-left-color: #f59e0b;
	background: #fffbeb;
}

.seo-forge-suggestions li.suggestion-low {
	border-left-color: #10b981;
	background: #f0fdf4;
}

.generated-image-result img {
	max-width: 100%;
	height: auto;
	border-radius: 4px;
	box-shadow: 0 2px 8px rgba(0,0,0,0.1);
}

.image-actions {
	margin-top: 10px;
	display: flex;
	gap: 10px;
}
</style>

<script>
jQuery(document).ready(function($) {
	// Use generated content
	$(document).on('click', '#use-content-btn', function() {
		var content = $('#generated-content').html();
		
		// Insert into WordPress editor
		if (typeof tinymce !== 'undefined' && tinymce.get('content')) {
			tinymce.get('content').setContent(content);
		} else if ($('#content').length) {
			$('#content').val(content);
		}
		
		SEOForgeAdmin.showNotice('success', '<?php esc_html_e( 'Content inserted successfully!', 'seo-forge' ); ?>');
	});

	// Regenerate content
	$(document).on('click', '#regenerate-content-btn', function() {
		$('#generate-content-btn').click();
	});

	// Auto-fill image prompt from keywords
	$('#seoforge-keywords').on('change', function() {
		var keywords = $(this).val();
		if (keywords && !$('#image-prompt').val()) {
			$('#image-prompt').val('Professional image related to: ' + keywords);
		}
	});
});
</script>