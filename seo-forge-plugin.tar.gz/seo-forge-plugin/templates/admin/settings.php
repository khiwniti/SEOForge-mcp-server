<?php
/**
 * SEO Forge Settings Template
 *
 * @package SEO_FORGE
 */

defined( 'ABSPATH' ) || exit;

use SEOForge\Helper;

// Handle form submission
if ( isset( $_POST['submit'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'seo_forge_settings' ) ) {
	update_option( 'seo_forge_api_url', sanitize_url( $_POST['api_url'] ) );
	update_option( 'seo_forge_api_key', sanitize_text_field( $_POST['api_key'] ) );
	update_option( 'seo_forge_default_language', sanitize_text_field( $_POST['default_language'] ) );
	update_option( 'seo_forge_auto_generate', isset( $_POST['auto_generate'] ) );
	update_option( 'seo_forge_enable_analytics', isset( $_POST['enable_analytics'] ) );
	update_option( 'seo_forge_enable_content_ai', isset( $_POST['enable_content_ai'] ) );
	update_option( 'seo_forge_enable_keyword_research', isset( $_POST['enable_keyword_research'] ) );
	
	// Homepage SEO settings
	update_option( 'seo_forge_homepage_title', sanitize_text_field( $_POST['homepage_title'] ) );
	update_option( 'seo_forge_homepage_description', sanitize_textarea_field( $_POST['homepage_description'] ) );
	update_option( 'seo_forge_homepage_keywords', sanitize_text_field( $_POST['homepage_keywords'] ) );
	
	// Social media settings
	update_option( 'seo_forge_twitter_handle', sanitize_text_field( $_POST['twitter_handle'] ) );
	update_option( 'seo_forge_facebook_app_id', sanitize_text_field( $_POST['facebook_app_id'] ) );
	
	// Webmaster tools
	update_option( 'seo_forge_google_analytics_id', sanitize_text_field( $_POST['google_analytics_id'] ) );
	update_option( 'seo_forge_google_search_console', sanitize_text_field( $_POST['google_search_console'] ) );
	update_option( 'seo_forge_bing_webmaster', sanitize_text_field( $_POST['bing_webmaster'] ) );
	
	echo '<div class="seo-forge-alert success"><p>' . esc_html__( 'Settings saved successfully!', 'seo-forge' ) . '</p></div>';
}

// Get current settings
$api_url = get_option( 'seo_forge_api_url', 'https://seoforge-mcp-platform.vercel.app' );
$api_key = get_option( 'seo_forge_api_key', '' );
$default_language = get_option( 'seo_forge_default_language', 'en' );
$auto_generate = get_option( 'seo_forge_auto_generate', false );
$enable_analytics = get_option( 'seo_forge_enable_analytics', true );
$enable_content_ai = get_option( 'seo_forge_enable_content_ai', true );
$enable_keyword_research = get_option( 'seo_forge_enable_keyword_research', true );

$homepage_title = get_option( 'seo_forge_homepage_title', '' );
$homepage_description = get_option( 'seo_forge_homepage_description', '' );
$homepage_keywords = get_option( 'seo_forge_homepage_keywords', '' );

$twitter_handle = get_option( 'seo_forge_twitter_handle', '' );
$facebook_app_id = get_option( 'seo_forge_facebook_app_id', '' );

$google_analytics_id = get_option( 'seo_forge_google_analytics_id', '' );
$google_search_console = get_option( 'seo_forge_google_search_console', '' );
$bing_webmaster = get_option( 'seo_forge_bing_webmaster', '' );
?>

<div class="wrap seo-forge-page">
	<div class="seo-forge-container">
		<div class="seo-forge-header">
			<h1><?php esc_html_e( 'SEO Forge Settings', 'seo-forge' ); ?></h1>
			<p><?php esc_html_e( 'Configure your SEO Forge plugin settings', 'seo-forge' ); ?></p>
		</div>

		<div style="padding: 30px;">
			<div class="seo-forge-tabs">
				<ul>
					<li><a href="#api-settings" class="active"><?php esc_html_e( 'API Settings', 'seo-forge' ); ?></a></li>
					<li><a href="#general-settings"><?php esc_html_e( 'General', 'seo-forge' ); ?></a></li>
					<li><a href="#homepage-seo"><?php esc_html_e( 'Homepage SEO', 'seo-forge' ); ?></a></li>
					<li><a href="#social-media"><?php esc_html_e( 'Social Media', 'seo-forge' ); ?></a></li>
					<li><a href="#webmaster-tools"><?php esc_html_e( 'Webmaster Tools', 'seo-forge' ); ?></a></li>
				</ul>
			</div>

			<form method="post" action="">
				<?php wp_nonce_field( 'seo_forge_settings' ); ?>

				<!-- API Settings Tab -->
				<div id="api-settings" class="seo-forge-tab-content active">
					<h2><?php esc_html_e( 'MCP Server Configuration', 'seo-forge' ); ?></h2>
					
					<div class="seo-forge-field">
						<label for="api_url"><?php esc_html_e( 'API URL', 'seo-forge' ); ?></label>
						<input type="url" id="api_url" name="api_url" value="<?php echo esc_attr( $api_url ); ?>" class="regular-text" required />
						<p class="description"><?php esc_html_e( 'The URL of your SEO Forge MCP server (e.g., https://your-domain.vercel.app)', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<label for="api_key"><?php esc_html_e( 'API Key', 'seo-forge' ); ?></label>
						<input type="password" id="api_key" name="api_key" value="<?php echo esc_attr( $api_key ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Your API key for authentication (optional but recommended for security)', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<button type="button" id="test-api-connection" class="seo-forge-button">
							<?php esc_html_e( 'Test Connection', 'seo-forge' ); ?>
						</button>
					</div>
				</div>

				<!-- General Settings Tab -->
				<div id="general-settings" class="seo-forge-tab-content">
					<h2><?php esc_html_e( 'General Settings', 'seo-forge' ); ?></h2>

					<div class="seo-forge-field">
						<label for="default_language"><?php esc_html_e( 'Default Language', 'seo-forge' ); ?></label>
						<select id="default_language" name="default_language">
							<?php foreach ( Helper::get_supported_languages() as $code => $name ) : ?>
								<option value="<?php echo esc_attr( $code ); ?>" <?php selected( $default_language, $code ); ?>>
									<?php echo esc_html( $name ); ?>
								</option>
							<?php endforeach; ?>
						</select>
						<p class="description"><?php esc_html_e( 'Default language for content generation and analysis', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<label>
							<input type="checkbox" name="auto_generate" <?php checked( $auto_generate ); ?> />
							<?php esc_html_e( 'Auto-generate content suggestions', 'seo-forge' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Automatically generate content suggestions when editing posts', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<label>
							<input type="checkbox" name="enable_analytics" <?php checked( $enable_analytics ); ?> />
							<?php esc_html_e( 'Enable Analytics', 'seo-forge' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Enable SEO analytics and performance tracking', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<label>
							<input type="checkbox" name="enable_content_ai" <?php checked( $enable_content_ai ); ?> />
							<?php esc_html_e( 'Enable Content AI', 'seo-forge' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Enable AI-powered content generation features', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<label>
							<input type="checkbox" name="enable_keyword_research" <?php checked( $enable_keyword_research ); ?> />
							<?php esc_html_e( 'Enable Keyword Research', 'seo-forge' ); ?>
						</label>
						<p class="description"><?php esc_html_e( 'Enable keyword research and analysis tools', 'seo-forge' ); ?></p>
					</div>
				</div>

				<!-- Homepage SEO Tab -->
				<div id="homepage-seo" class="seo-forge-tab-content">
					<h2><?php esc_html_e( 'Homepage SEO Settings', 'seo-forge' ); ?></h2>

					<div class="seo-forge-field">
						<label for="homepage_title"><?php esc_html_e( 'Homepage Title', 'seo-forge' ); ?></label>
						<input type="text" id="homepage_title" name="homepage_title" value="<?php echo esc_attr( $homepage_title ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Custom title for your homepage (leave empty to use site title)', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<label for="homepage_description"><?php esc_html_e( 'Homepage Meta Description', 'seo-forge' ); ?></label>
						<textarea id="homepage_description" name="homepage_description" rows="3" class="large-text"><?php echo esc_textarea( $homepage_description ); ?></textarea>
						<p class="description"><?php esc_html_e( 'Meta description for your homepage (leave empty to use site tagline)', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<label for="homepage_keywords"><?php esc_html_e( 'Homepage Keywords', 'seo-forge' ); ?></label>
						<input type="text" id="homepage_keywords" name="homepage_keywords" value="<?php echo esc_attr( $homepage_keywords ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Keywords for your homepage, separated by commas', 'seo-forge' ); ?></p>
					</div>
				</div>

				<!-- Social Media Tab -->
				<div id="social-media" class="seo-forge-tab-content">
					<h2><?php esc_html_e( 'Social Media Settings', 'seo-forge' ); ?></h2>

					<div class="seo-forge-field">
						<label for="twitter_handle"><?php esc_html_e( 'Twitter Handle', 'seo-forge' ); ?></label>
						<input type="text" id="twitter_handle" name="twitter_handle" value="<?php echo esc_attr( $twitter_handle ); ?>" class="regular-text" placeholder="username" />
						<p class="description"><?php esc_html_e( 'Your Twitter username (without @)', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<label for="facebook_app_id"><?php esc_html_e( 'Facebook App ID', 'seo-forge' ); ?></label>
						<input type="text" id="facebook_app_id" name="facebook_app_id" value="<?php echo esc_attr( $facebook_app_id ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Facebook App ID for Open Graph integration', 'seo-forge' ); ?></p>
					</div>
				</div>

				<!-- Webmaster Tools Tab -->
				<div id="webmaster-tools" class="seo-forge-tab-content">
					<h2><?php esc_html_e( 'Webmaster Tools', 'seo-forge' ); ?></h2>

					<div class="seo-forge-field">
						<label for="google_analytics_id"><?php esc_html_e( 'Google Analytics ID', 'seo-forge' ); ?></label>
						<input type="text" id="google_analytics_id" name="google_analytics_id" value="<?php echo esc_attr( $google_analytics_id ); ?>" class="regular-text" placeholder="G-XXXXXXXXXX" />
						<p class="description"><?php esc_html_e( 'Your Google Analytics 4 Measurement ID', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<label for="google_search_console"><?php esc_html_e( 'Google Search Console', 'seo-forge' ); ?></label>
						<input type="text" id="google_search_console" name="google_search_console" value="<?php echo esc_attr( $google_search_console ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Google Search Console verification meta tag content', 'seo-forge' ); ?></p>
					</div>

					<div class="seo-forge-field">
						<label for="bing_webmaster"><?php esc_html_e( 'Bing Webmaster Tools', 'seo-forge' ); ?></label>
						<input type="text" id="bing_webmaster" name="bing_webmaster" value="<?php echo esc_attr( $bing_webmaster ); ?>" class="regular-text" />
						<p class="description"><?php esc_html_e( 'Bing Webmaster Tools verification meta tag content', 'seo-forge' ); ?></p>
					</div>
				</div>

				<div style="margin-top: 30px;">
					<?php submit_button( __( 'Save Settings', 'seo-forge' ), 'primary', 'submit', false, [ 'class' => 'seo-forge-button' ] ); ?>
				</div>
			</form>
		</div>
	</div>
</div>