<?php
/**
 * SEO Forge Dashboard Template
 *
 * @package SEO_FORGE
 */

defined( 'ABSPATH' ) || exit;

use SEOForge\Helper;

$api_status = seo_forge()->get_container( 'mcp_client' )->get_api_status();
$plugin_info = Helper::get_plugin_info();
?>

<div class="wrap seo-forge-page">
	<div class="seo-forge-container">
		<div class="seo-forge-header">
			<h1><?php echo esc_html( $plugin_info['name'] ); ?></h1>
			<p><?php esc_html_e( 'Universal SEO WordPress Plugin with AI-powered content generation and optimization', 'seo-forge' ); ?></p>
		</div>

		<?php if ( ! $api_status['configured'] ) : ?>
			<div class="seo-forge-alert warning">
				<p>
					<?php
					printf(
						esc_html__( 'Welcome to SEO Forge! To get started, please %s to configure your MCP server connection.', 'seo-forge' ),
						'<a href="' . esc_url( admin_url( 'admin.php?page=seo-forge-settings' ) ) . '">' . esc_html__( 'go to settings', 'seo-forge' ) . '</a>'
					);
					?>
				</p>
			</div>
		<?php endif; ?>

		<div class="seo-forge-dashboard">
			<!-- API Status Card -->
			<div class="seo-forge-card">
				<h3><?php esc_html_e( 'API Status', 'seo-forge' ); ?></h3>
				<div class="api-status-info">
					<p><strong><?php esc_html_e( 'Connection:', 'seo-forge' ); ?></strong> 
						<span class="status-indicator <?php echo $api_status['connected'] ? 'connected' : 'disconnected'; ?>">
							<?php echo $api_status['connected'] ? esc_html__( 'Connected', 'seo-forge' ) : esc_html__( 'Disconnected', 'seo-forge' ); ?>
						</span>
					</p>
					<p><strong><?php esc_html_e( 'Server:', 'seo-forge' ); ?></strong> <?php echo esc_html( $api_status['url'] ); ?></p>
					<?php if ( ! empty( $api_status['error'] ) ) : ?>
						<p class="error-message"><strong><?php esc_html_e( 'Error:', 'seo-forge' ); ?></strong> <?php echo esc_html( $api_status['error'] ); ?></p>
					<?php endif; ?>
				</div>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=seo-forge-settings' ) ); ?>" class="seo-forge-button">
					<?php esc_html_e( 'Configure API', 'seo-forge' ); ?>
				</a>
			</div>

			<!-- Content Generator Card -->
			<div class="seo-forge-card">
				<h3><?php esc_html_e( 'Content Generator', 'seo-forge' ); ?></h3>
				<p><?php esc_html_e( 'Generate SEO-optimized content using AI. Create blog posts, product descriptions, and more with just a few keywords.', 'seo-forge' ); ?></p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=seo-forge-content-generator' ) ); ?>" class="seo-forge-button">
					<?php esc_html_e( 'Generate Content', 'seo-forge' ); ?>
				</a>
			</div>

			<!-- SEO Analyzer Card -->
			<div class="seo-forge-card">
				<h3><?php esc_html_e( 'SEO Analyzer', 'seo-forge' ); ?></h3>
				<p><?php esc_html_e( 'Analyze your content for SEO optimization. Get detailed reports and actionable recommendations to improve your rankings.', 'seo-forge' ); ?></p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=seo-forge-seo-analyzer' ) ); ?>" class="seo-forge-button">
					<?php esc_html_e( 'Analyze SEO', 'seo-forge' ); ?>
				</a>
			</div>

			<!-- Keyword Research Card -->
			<div class="seo-forge-card">
				<h3><?php esc_html_e( 'Keyword Research', 'seo-forge' ); ?></h3>
				<p><?php esc_html_e( 'Discover high-value keywords for your content strategy. Find search volume, difficulty, and competition data.', 'seo-forge' ); ?></p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=seo-forge-keyword-research' ) ); ?>" class="seo-forge-button">
					<?php esc_html_e( 'Research Keywords', 'seo-forge' ); ?>
				</a>
			</div>

			<!-- Analytics Card -->
			<div class="seo-forge-card">
				<h3><?php esc_html_e( 'Analytics', 'seo-forge' ); ?></h3>
				<p><?php esc_html_e( 'Track your SEO performance with detailed analytics. Monitor rankings, traffic, and conversion metrics.', 'seo-forge' ); ?></p>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=seo-forge-analytics' ) ); ?>" class="seo-forge-button">
					<?php esc_html_e( 'View Analytics', 'seo-forge' ); ?>
				</a>
			</div>

			<!-- Quick Actions Card -->
			<div class="seo-forge-card">
				<h3><?php esc_html_e( 'Quick Actions', 'seo-forge' ); ?></h3>
				<div class="quick-actions">
					<a href="<?php echo esc_url( admin_url( 'post-new.php' ) ); ?>" class="seo-forge-button secondary">
						<?php esc_html_e( 'Create New Post', 'seo-forge' ); ?>
					</a>
					<a href="<?php echo esc_url( admin_url( 'edit.php' ) ); ?>" class="seo-forge-button secondary">
						<?php esc_html_e( 'Edit Posts', 'seo-forge' ); ?>
					</a>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=seo-forge-settings' ) ); ?>" class="seo-forge-button secondary">
						<?php esc_html_e( 'Settings', 'seo-forge' ); ?>
					</a>
				</div>
			</div>
		</div>

		<!-- Recent Activity -->
		<div style="padding: 30px;">
			<h2><?php esc_html_e( 'Recent Activity', 'seo-forge' ); ?></h2>
			<div id="recent-activity">
				<p><?php esc_html_e( 'No recent activity to display.', 'seo-forge' ); ?></p>
			</div>
		</div>
	</div>
</div>

<style>
.status-indicator {
	padding: 4px 8px;
	border-radius: 4px;
	font-size: 12px;
	font-weight: bold;
}

.status-indicator.connected {
	background: #d1fae5;
	color: #065f46;
}

.status-indicator.disconnected {
	background: #fee2e2;
	color: #991b1b;
}

.error-message {
	color: #ef4444;
	font-size: 13px;
}

.quick-actions {
	display: flex;
	gap: 10px;
	flex-wrap: wrap;
}

.quick-actions .seo-forge-button {
	flex: 1;
	min-width: 120px;
	text-align: center;
}

@media (max-width: 768px) {
	.quick-actions {
		flex-direction: column;
	}
	
	.quick-actions .seo-forge-button {
		flex: none;
	}
}
</style>