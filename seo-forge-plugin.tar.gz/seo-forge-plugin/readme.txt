=== SEO Forge ===
Contributors: seoforge
Tags: seo, content generation, ai, keyword research, analytics
Requires at least: 5.0
Tested up to: 6.4
Requires PHP: 7.4
Stable tag: 1.0.0
License: MIT
License URI: https://opensource.org/licenses/MIT

Universal SEO WordPress plugin with AI-powered content generation, SEO analysis, and comprehensive optimization tools. No license required.

== Description ==

SEO Forge is a comprehensive SEO plugin that combines the power of AI-driven content generation with advanced SEO analysis and optimization tools. Built to work seamlessly with your existing MCP (Model Context Protocol) server, it provides everything you need to optimize your WordPress site for search engines.

= Key Features =

* **AI-Powered Content Generation**: Generate high-quality, SEO-optimized content using advanced AI models
* **Comprehensive SEO Analysis**: Analyze your content for SEO optimization with detailed reports and recommendations
* **Keyword Research**: Discover high-value keywords with search volume, difficulty, and competition data
* **Image Generation**: Create custom images for your content using AI
* **Real-time SEO Scoring**: Get instant feedback on your content's SEO performance
* **Meta Tag Optimization**: Automatically optimize titles, descriptions, and meta tags
* **Schema Markup**: Add structured data to improve search engine understanding
* **Analytics Integration**: Track your SEO performance with detailed analytics
* **Multi-language Support**: Generate content in multiple languages
* **No License Required**: Completely free and open-source

= Professional UI =

SEO Forge features a modern, professional interface inspired by the best SEO tools in the industry. The clean design and intuitive workflow make it easy for both beginners and experts to optimize their content effectively.

= MCP Server Integration =

This plugin is designed to work with your SEO Forge MCP server, providing seamless integration between your WordPress site and AI-powered SEO tools. Simply configure your MCP server URL in the settings and start generating optimized content.

= Supported Content Types =

* Blog posts and articles
* Product descriptions
* Landing pages
* How-to guides
* News articles
* And more...

== Installation ==

1. Upload the plugin files to the `/wp-content/plugins/seo-forge` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress.
3. Go to SEO Forge > Settings to configure your MCP server connection.
4. Start optimizing your content with AI-powered SEO tools!

== Frequently Asked Questions ==

= Do I need a license to use SEO Forge? =

No! SEO Forge is completely free and open-source. There are no license requirements or restrictions.

= What is an MCP server? =

MCP (Model Context Protocol) is a standard for connecting AI models and tools. Your MCP server provides the AI capabilities that power SEO Forge's content generation and analysis features.

= Can I use SEO Forge without an MCP server? =

While some basic SEO features will work without an MCP server, you'll need one configured to access the AI-powered content generation and advanced analysis features.

= Is my data secure? =

Yes, all communication with your MCP server is encrypted and secure. SEO Forge only sends the content you explicitly choose to analyze or optimize.

= Can I generate content in languages other than English? =

Yes! SEO Forge supports content generation in multiple languages including English, Thai, Spanish, French, German, Italian, Portuguese, Russian, Japanese, Korean, and Chinese.

== Screenshots ==

1. Dashboard overview with API status and quick actions
2. Content generator with AI-powered suggestions
3. SEO analysis with detailed scoring and recommendations
4. Keyword research with search volume and difficulty data
5. Professional meta box interface for post editing
6. Settings page with MCP server configuration

== Changelog ==

= 1.0.0 =
* Initial release
* AI-powered content generation
* Comprehensive SEO analysis
* Keyword research tools
* Image generation capabilities
* Professional UI design
* MCP server integration
* Multi-language support
* Analytics and reporting
* Meta tag optimization
* Schema markup support

== Upgrade Notice ==

= 1.0.0 =
Initial release of SEO Forge - the universal SEO plugin with AI-powered features.

== Support ==

For support and documentation, visit: https://github.com/khiwniti/SEOForge-mcp-server

== Contributing ==

SEO Forge is open-source and welcomes contributions. Visit our GitHub repository to contribute or report issues.