<?php
/**
 * SEO Forge Uninstall Script
 *
 * @package SEO_FORGE
 */

// If uninstall not called from WordPress, then exit.
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

// Include the installer class for cleanup
require_once plugin_dir_path( __FILE__ ) . 'includes/class-installer.php';

// Run uninstall cleanup
SEOForge\Installer::uninstall();